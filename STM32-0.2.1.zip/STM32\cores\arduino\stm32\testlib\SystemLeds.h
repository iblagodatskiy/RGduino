#pragma once
#include "Types.h"
#include "Config.h"

class Led final
{
	friend class LedGroup;
	byte number;

	Led(byte num);

public:
	void on();
	void off();
	void invert();
	bool get();
};

class LedGroup
{
public:
	Led	green;
	Led	red;
	Led	blue;

	LedGroup();
};
