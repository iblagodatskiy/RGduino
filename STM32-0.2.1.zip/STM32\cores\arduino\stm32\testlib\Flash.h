#pragma once

#include "Types.h"
#include "GPIOLib.h"
#include "CoreSettings.h"

#define CS_PIN		15
#define WE_PIN		14
#define RESET_PIN	13

#define CS_EN		GPIOresetPin(GPIOG, CS_PIN)
#define CS_DIS		GPIOsetPin(GPIOG, CS_PIN)
#define WE_EN		GPIOresetPin(GPIOG, WE_PIN)
#define WE_DIS		GPIOsetPin(GPIOG, WE_PIN)
#define RESET_EN	GPIOresetPin(GPIOG, RESET_PIN)
#define RESET_DIS	GPIOsetPin(GPIOG, RESET_PIN)

#define PAGE_NUM_BYTES				256
#define SECTOR_NUM_BYTES			4096
#define BLOCK_NUM_BYTES				65535


#define FLASH_BEGIN_ADDR			0x00
#define FLASH_END_ADDR				0x3FFFFF

#define TIMEOUT_FLASH				0x5000
#define TIMEOUT_ESECTOR				0x50000
#define REPEAT_TIMES_MAX			400

#define WRITE_ENABLE 				0x06
#define WRITE_DISABLE 				0x04
#define READ_STATUS_REGISTER_1 		0x05
#define READ_STATUS_REGISTER_2 		0x35
#define READ_STATUS_REGISTER_3 		0x15
#define WRITE_STATUS_REGISTER_1 	0x01
#define WRITE_STATUS_REGISTER_2 	0x31
#define WRITE_STATUS_REGISTER_3 	0x11
#define CHIP_ERASE				 	0x60//0xC7
#define SECTOR_ERASE				0x20//4kb
#define BLOCK_ERASE				 	0xD8//64kb
#define HBLOCK_ERASE				0x52//32kb
#define JEDEC_ID				 	0x9F
#define PAGE_PROGRAM			 	0x02
#define READ_DATA				 	0x03

class FlashT
{
	bool rwByte(byte wByte, byte &rByte);
	bool eSegment(uint address, byte segment);
	bool sendComAddr(byte com, uint address);
	bool rSR(byte reg, byte &data);
	bool wSR(byte reg, byte data);
protected:
	FlashT();
public:
	static FlashT & instance();
	bool rJEDEC_ID(byte *buf);
	bool rSR1(byte &SR);
	bool rSR2(byte &SR);
	bool rSR3(byte &SR);
	bool wSR1(byte SR);
	bool wSR2(byte SR);
	bool wSR3(byte SR);
	bool wWEN();
	bool wWDIS();
	bool eSector(uint address, byte autorepeat = 1); // Erase 4kb
	bool eBlock(uint address, byte autorepeat = 1); // Erase 64kb
	bool ehBlock(uint address, byte autorepeat = 1); // Erase 32kb
	bool eFull(byte autorepeat = 1);
	bool wBuf(uint address, byte *buf, uint size, byte autorepeat = 1);
	bool rBuf(uint address, byte *buf, uint size, byte autorepeat = 1);
	bool wPage(uint address, byte *buf, byte autorepeat = 1);
	bool rPage(uint address, byte* buf, byte autorepeat = 1);
	bool isBusy();
};
