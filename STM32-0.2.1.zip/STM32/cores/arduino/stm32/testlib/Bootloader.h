#pragma once

#include "Types.h"
#include "MyMath.h"
#include "Config.h"


class BootRecordPage
{
public:
	byte key[16];
	bool firmwareExist;
	byte RESERVED1[3];
	uint size;
	uint crc;
	byte RESERVED2[256	- sizeof(BootRecordPage::key)
						- sizeof(BootRecordPage::firmwareExist)
						- sizeof(BootRecordPage::RESERVED1)
						- sizeof(BootRecordPage::size)
						- sizeof(BootRecordPage::crc)
						- 4
						- 12];
	uint pageCRC;
	byte endOfPage[12];
	uint calculateCRC();
	bool validatePage();
	void fillPage(bool exist = false);
};

class EEPROM_BootPage
{
public:
	byte key[4];
	bool needToUpdateFirmware;
	bool FirmwareUpdated;
	byte group;
	byte RESERVED;
	uint pageCRC;
	byte endOfPage[4];
	uint calculateCRC();
	bool validatePage();
	void fillPage(bool ntu = false, bool fu = false); // ntu - need to update
};

enum class BootloaderStatus : byte
{
	Disabled,
	TransmittingData,
	ReceiverFlashError,
	ReceiverFirmwareReadyToUpdate,
	ReceiverFirmwareUpdating,
	Success
};

enum class UCextFlashStatus
{
	Busy,
	Initialized,
	Error
};

enum class HostBootStat
{
	Disabled,
	Clearing,
	WritingFlash,
	Checking,
	WritingBootPage,
	FlashWait,
	ReadyToUpdate
};

class Bootloader
{
public:
	struct Info
	{
		uint size;
		uint crc32;
	}info;
	struct Page
	{
		uint crc32;
		ushort step;
		byte data[BOOTLOADER_BUFFER_SIZE];
	}page;
	byte *ptr;
	ushort step;
	bool activityOngoing;
	bool autoRestart;
	static bool initialized;
	BootloaderStatus txStatus;
	Bootloader() {zeroMemory(this, sizeof(Bootloader));}
};
