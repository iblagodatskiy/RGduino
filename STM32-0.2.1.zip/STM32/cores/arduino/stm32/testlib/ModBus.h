#pragma once

#include "Types.h"
#include "Manager.h"
#include "Config.h"

typedef enum {
	ILLEGAL_FUNCTION = 0x1,	/* The accepted function code cannot be processed. */
	ILLEGAL_DATA_ADDRESS,		/* The data address specified in the request is not available */
	ILLEGAL_DATA_VALUE,		/*  The value contained in the query data field is not a valid value.*/
	SLAVE_DEVICE_FAILURE,		/* An unrecoverable error occurred while the slave was attempting to perform the requested action */
	ACKNOWLEDGE,		/* The slave has accepted the request and is processing it, but it takes a long time */
	SLAVE_DEVICE_BUSY,		/*  The slave is engaged in processing a long�duration program command*/
	NEGATIVE_ACKNOWLEDGE,		/* The slave cannot perform the program function received in the query */
	MEMORY_PARITY_ERROR,		/* The slave attempted to read extended memory. */
} MODBUS_ERR;

typedef enum {
	BYTE_SLAVE_ADDR=0,
	BYTE_FUNC_CODE,
	BYTE_COUNT,
} BYTE_CODE;

struct array_buf
{
	byte start;
	byte cnt;
};

class MBparameter
{
	static MBparameter *params[MODBUS_PARAMS_NUMBER];
	static uint16_t paramsCount;
	static byte bufRx[MODBUS_BUFFER_NUMBER];
	static byte bufCntRx;
	static byte buf[MODBUS_BUFFER_NUMBER];

	static byte bufTx[MODBUS_BUFFER_NUMBER];
	static byte bufCnt;
	static byte bufCntTx;
	static byte txSize;
	static bool txOngoing;
	static uint32_t timer;
	static uint32_t time_cnt;
	static byte SLAVE_ADDR;

	uint32_t value;
	ushort myCRC;
	byte bitCap;
	uint16_t ID;
	byte offset;
	byte CODE;
	bool is_autograph;

	typedef struct
	{
		uint32_t timeWait;
		uint32_t current_time;
		bool isConnect;
	}NodeWait;

	static NodeWait nodewait;

	static bool request;
	static bool enabled;
	static bool is_launch;
	static void rxHandler(byte data);
	static void txHandler();
	static void manager();
public:
	bool newData;
	MBparameter(byte codeParam, uint16_t idParam, byte numWord);
	MBparameter(uint16_t idParam, byte numWord);
	void setValue(uint32_t val);
	void setValueAutograph(uint32_t val);
	static void setSlaveAddress(uint32_t val);
	static uint32_t getSlaveAddress();
	uint32_t getValue();
	int32_t getValueSigned();
	bool isHitAnswer(byte data);
	byte preparePacket(byte *buf);
	static void sendError(MODBUS_ERR err_code);
	static void ReadData(uint16_t start_addr, uint count_reg, bool is_analog);
	static void addCRCandSend(byte start_byte);
	static void WriteOne(uint16_t start_addr, bool is_analog);
	static void WriteMultiple(uint16_t start_addr, uint count_reg, bool is_analog);
	static void enable();
	static void disable();
	static void setNodeWait(uint32_t time_wait);//time_wait in ms
	static bool getNodeWait();
};

