/*
 * DPLedKey.h
 *
 *  Created on: 27 ���. 2021 �.
 *      Author: arusakov
 */

#ifndef INC_DPLEDKEY_H_
#define INC_DPLEDKEY_H_

class DPContainer {
public:
	enum Led { LED_A, LED_B, LED_C, LED_D, NON_SLEEP_UP_BIT = 30, SMART_SAFETY_UP_BIT = 31};

	enum Key { UP, DOWN, LEFT, RIGHT, LEFT_DOWN, RIGHT_UP, K1, K2, K3, K4, K5, K6, EMERGENCY = 28, NON_SLEEP_DOWN_BIT = 30, SMART_SAFETY_DOWN_BIT = 31};

};


#endif /* INC_DPLEDKEY_H_ */
