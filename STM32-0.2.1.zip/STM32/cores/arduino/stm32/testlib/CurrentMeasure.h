#pragma once

#include "Types.h"

class CurrentMeasure
{
protected:
	static byte curEnMask;
	static byte needToMeasure;
	static float current[8];
};