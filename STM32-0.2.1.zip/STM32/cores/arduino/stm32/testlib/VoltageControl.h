#pragma once

#include "Types.h"
#include "Config.h"

class VoltageControl
{
	static float buf[VOLTAGE_CONTROL_BUF_SIZE];
	static float min;
	static float max;
	static bool akbOn;
	byte counter;

	static void calcAvg();
public:
	VoltageControl();
	bool getAKB();
	void next(float val);
};
