#pragma once

#include "UCdevice.h"
#include "DoubleTimerExtended.h"

extern "C"
{
	void TIM5_IRQHandler();
}

class Timer5 : public DoubleTimerExtended
{
	friend class Periphery;
	friend void TIM5_IRQHandler();

	static Timer5 *module;

	Timer5(UCdevice &dev);
};
