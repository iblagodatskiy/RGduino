#pragma once

#include "Types.h"
#include "InputChannel.h"
#include "ShiftRegControl.h"

class InputControl : Hardware::ShiftRegControl
{
public:
	enum class PullDown : byte
	{
		High,
		Medium,
		Low,
		Digit
	};
	enum class PullUp : byte
	{
		Disabled,
		Enabled
	};
	enum class Source : byte
	{
		Analog,
		Schmitt
	};
	enum class CurrentLoop : byte
	{
		Disabled,
		Enabled
	};
	enum class LPF : byte// Low pass filter
	{
		Disabled,
		Low,
		Medium,
		High
	};
	struct Setting
	{
		PullDown	pullDown	: 2;
		PullUp		pullUp		: 1;
		Source		source		: 1;
		CurrentLoop	currentLoop	: 1;
		LPF			lpf			: 2;
	};
	InputControl();
	static bool updateTable(byte channel, Setting setting);
	static bool set(byte channel, Setting setting);
	static void set();
	bool set(byte channel, InputChannelSettings &setting);
	bool reset(byte channel);
private:
	static ushort buf[7];
};
