#pragma once
#include "Timer.h"
#include "Types.h"
#include "stdint.h"
#include "Config.h"
#include "ClockSource.h"

#define RTC_LSE_TIMEOUT 5000
#define RTC_LOCK_TIMEOUT 5000000

struct DATETIME_t {
	uint64_t hour :5;
	uint64_t minute :6;
	uint64_t sec :6;
	uint64_t year :12;
	uint64_t month :4;
	uint64_t weekDay :3;
	uint64_t day :5;
	uint64_t :16;
} __attribute__ ((packed));

struct FLASH_DATETIME_t{
	DATETIME_t data;
	byte crc;
}  __attribute__ ((packed));

class RTCt : System::Timer
{
	private:

	bool is_enable;
	const uint8_t month_days[12]={31,28,31,30,31,30,31,31,30,31,30,31};

	uint32_t _lseStartTimeout = RTC_LSE_TIMEOUT;
	ClockSource _clockSource = ClockSource::None;

	RTCt();
	virtual void tick_1Min();
	bool unlockChange();
	void lockChange();
	bool LSE_start();
	bool LSI_start();
	void init();
	void lseRtcStartFail();
public:
	static RTCt & instance();
	void setTimeDate(DATETIME_t *time);
	DATETIME_t getTimeDate();
	bool setTimeStamp();//for current time and date
	bool setTimeStamp(FLASH_DATETIME_t *timedate);
	DATETIME_t getTimeStamp();
	uint32_t getAllHours();
	void enable();
	void disable();
	void reset();
	void setRtcLseStartTimeout(uint32_t timeout);
	ClockSource getClockSource();
};
