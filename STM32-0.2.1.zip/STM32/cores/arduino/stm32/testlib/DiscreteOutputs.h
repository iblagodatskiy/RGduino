#pragma once
#include "Types.h"
#include "ShiftRegControl.h"
#include "Config.h"
#include "Dispatch.h"

#define DISCRETE_OUTPUTS_COUNT 16U

class DiscreteOutputs: public Hardware::ShiftRegControl {
	private:

		struct OutputSettings {
				Dispatch dispatch;
		};

		struct OutputsSettings {
				OutputSettings channels[DISCRETE_OUTPUTS_COUNT];
				Dispatch statusDispatch;
		};

		ushort enabled;
		bool valueChanged = false;
#if (OVER_LOAD_CONTROL ==0)
		ushort value;
#endif // !OVER_LOAD_CONTROL
	public:

		OutputsSettings settings;

		DiscreteOutputs();
		bool enable(byte channel);
		void enableMask(ushort mask);
		bool isEnabled(byte channel);
		ushort getEnabledMask();
		bool disable(byte channel);
		void disableMask(ushort mask);
		bool set(byte channel, bool state);
		bool update();
		bool setValue(ushort val);
		bool setMask(ushort mask);
		bool setByMask(ushort val, ushort mask);
		bool toggle(byte channel);
		bool toggleMask(ushort mask);
		bool resetMask(ushort mask);
		ushort get();
		bool get(byte channel);
		ushort getStatus();
		bool getStatus(byte channel);
		ushort getSwitchStatus();
		bool getSwitchStatus(byte channel);

};
