#ifndef _SHAREDMACRO_H_
#define _SHAREDMACRO_H_

#ifndef MAKE_MACRO_D
#define MAKE_MACRO_D(lft, rght) lft##rght
#endif

#ifndef MAKE_MACRO
#define MAKE_MACRO(lft, rght) MAKE_MACRO_D(lft, rght)
#endif

#ifndef __LOCAL_FUNC
#define __LOCAL_FUNC static inline
#endif

#ifndef __WEAK
#define __WEAK __attribute__((weak))
#endif

#endif /* _SHAREDMACRO_H_ */
