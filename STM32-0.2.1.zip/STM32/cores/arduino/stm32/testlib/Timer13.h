#pragma once

#include "UCdevice.h"
#include "SingleTimer.h"

extern "C"
{
	void TIM8_UP_TIM13_IRQHandler();
}

class Timer13 : public SingleTimer
{
	friend class Periphery;
	friend void TIM8_UP_TIM13_IRQHandler();

	static Timer13 *module;

	Timer13(UCdevice &dev);
};
