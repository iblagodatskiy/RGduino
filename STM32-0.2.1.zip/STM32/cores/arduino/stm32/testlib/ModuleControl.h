#pragma once
#include "Peripheral.h"
#include "Module.h"
#include "CANContainer.h"

#define TIMEOUT_RX_DATA	500
#define NUMBER_RADIO_UNITS	  4


typedef enum
{
	PULT_NONE=0,
	PULT_LOCAL,
	PULT_REMOTE_RADIO,
	PULT_REMOTE_CAN,
	PULT_WAIT,
}PULT_TYPE_CONNECTION;

typedef enum
{
	ONE_PULT=0,/*Один пульт и один радиомодуль - подключение либо по кабелю либо по радио, в шине CAN один ID пульта (например 0x18FF2025)*/
	TWO_PULTS_ONE_CAN,/*Два пульта и один радимодуль- один пульт постоянно подключен к шине CAN, второй пульт общается либо по кабелю либо по радио,
	одна шина CAN, в которой два CAN ID пультов(например 0x18FF2025-локальный и 0x18FF2035-дистанционный)*/
	TWO_PULTS_TWO_CAN,/*Два пульта и три радимодуля (один радимодуль для связи с дистанционным пультом, остальные два - для обмена данными по радио между двумя шинами CAN)
	один пульт постоянно подключен к первой шине CAN,
	второй пульт общается либо через вторую шину по кабель->радиомодуль либо по радио,
	в первой шине три CAN ID пультов(например 0x18FF2025-локальный, 0x18FF2035-дистанционный, 0x18FF2045-дистанционный по кабелю),
	во второй шине один ID пульта (например 0x18FF2055)*/
}TOPOLOGY_CONNECTION;

typedef enum
{
	RECIEVE_NONE=0,
	RECIEVE_RADIO,
	RECIEVE_ANGLE,
	RECIEVE_CONFIG
}RECIEVE_TYPE;

struct Filters
{
	uint32_t id=0;
	SCALE_FILTER scale=SCALE_11bit;
};
/*
 * example arrays filters
 *
#define FILTER_CAN_ID_STD_0					0x25
#define FILTER_CAN_ID_STD_1					0x26
#define FILTER_CAN_ID_STD_2					0x27
#define FILTER_CAN_ID_STD_3					0x28
#define FILTER_CAN_ID_EXT_4					CAN_BASE_ANGLE_SENSOR_DEF
#define FILTER_CAN_ID_EXT_5					CAN_COIL_FEEDBACK_ID_0
#define FILTER_CAN_ID_EXT_6					CAN_COIL_FEEDBACK_ID_1
#define FILTER_CAN_ID_EXT_7					CAN_COIL_FEEDBACK_ID_2
#define FILTER_CAN_ID_EXT_8					CAN_COIL_FEEDBACK_ID_3

const Filters filters[9]={
		{FILTER_CAN_ID_STD_0,SCALE_11bit},
		{FILTER_CAN_ID_STD_1,SCALE_11bit},
		{FILTER_CAN_ID_STD_2,SCALE_11bit},
		{FILTER_CAN_ID_STD_3,SCALE_11bit},
		{FILTER_CAN_ID_EXT_4,SCALE_29bit},
		{FILTER_CAN_ID_EXT_5,SCALE_29bit},
		{FILTER_CAN_ID_EXT_6,SCALE_29bit},
		{FILTER_CAN_ID_EXT_7,SCALE_29bit},
		{FILTER_CAN_ID_EXT_8,SCALE_29bit},
};
call function:

setFiltersRadio(&filters,9);
 *
 */

class ModuleControl
{
private:
	friend class System::Timer;
	friend class System::Manager;

	Module *module=nullptr;
	volatile bool is_rx_config = false;
	volatile bool is_rx_rssi = false;
	byte in_key=255;
	byte out_state=255;
	Filters *ptr_filters=nullptr;
	byte cnt_filters=0;
	uint32_t config_id=CAN_BASE_RADIO_CONFIG;
	uint32_t radio_id=CAN_BASE_RADIO_DATA;
	uint32_t sens_id=CAN_BASE_ANGLE_SENSOR_DEF;
	bool is_new_data_key=false;
	uint8_t local_index=0;
	bool is_enable_radio=false;
	bool is_enable_angle=false;

	static void init0();
	static void init1();
	static void init2();
	static void init3();
	static void init(uint8_t ind);
	static void checkState0();
	static void checkState1();
	static void checkState2();
	static void checkState3();
	static void checkState(uint8_t ind);
	static bool checkRecieve(uint8_t ind);
	static void keyPress0();
	static void keyPress1();
	static void keyPress2();
	static void keyPress3();
	static void keyPress(uint8_t ind);
	static void setToBind0(bool is_bind=true);
	static void setToBind1(bool is_bind=true);
	static void setToBind2(bool is_bind=true);
	static void setToBind3(bool is_bind=true);
	static void setToBind(uint8_t ind, bool is_bind=true);
	static void checkRSSI0();
	static void checkRSSI1();
	static void checkRSSI2();
	static void checkRSSI3();
	static void checkRSSI(uint8_t ind);
	static void recieveConfigCallback(uint32_t id, byte *buf, byte dlc);
	static void recieveDataCallback(uint32_t id, byte *buf, byte dlc);
	static void timeoutRecieveData0();
	static void timeoutRecieveData1();
	static void timeoutRecieveData2();
	static void timeoutRecieveData3();
	static void timeoutRecieveConfig0();
	static void timeoutRecieveConfig1();
	static void timeoutRecieveConfig2();
	static void timeoutRecieveConfig3();
	static void timeoutRecieve(uint8_t ind, RECIEVE_TYPE rx_type);
	bool setFltrsRf();

protected:
public:
	MESSAGE_KEY rx_key;
	MESSAGE_JOY rx_joy_0_3;
	MESSAGE_JOY rx_joy_4_7;
	MESSAGE_LEDMASK tx_ledmask;
	MESSAGE_LEDMASK_EXT tx_ledmask_ext;
	MESSAGE_FEEDBACK tx_feedback;
	MESSAGE_FEEDBACK_EXT tx_feedback_ext;
	MESSAGE_STATUS tx_status;
	MESSAGE_STRING tx_string;
	MESSAGE_ANGLE_EULER sens;
	StringContainer pult_string_0;
	StringContainer pult_string_1;
	PULT_TYPE_CONNECTION typeConnect = PULT_WAIT;
	bool is_ext_led=false;
	bool newDataRadio = false;
	bool newDataKey = false;
	bool newDataSens = false;
	uint32_t timeRxDataRadio = 0;
	uint32_t timeRxDataSens = 0;
	uint32_t timeRxConf = 0;
	uint8_t is_rx_string_mask=0;
	bool setFiltersRadio(Filters *ptr, byte count);
	bool enableRecieve(RECIEVE_TYPE enable_rx);
	bool disableRecieve(RECIEVE_TYPE rx_type);
	float getValueJoy(uint8_t index, bool &is_calibrate);
	bool getValueKey(uint8_t index);
	bool getValueLed(uint8_t index);
	bool getValueLedExt(uint8_t index);
	bool getMaskLed(uint8_t index);
	bool getMaskLedExt(uint8_t index);
	void setValueJoy(uint8_t index, float value, bool _is_calibrate);
	void setValueKey(uint8_t index, bool value);
	void sendControl();
	void sendFeedBack();
	void sendString(char *str_line_0,char *str_line_1=nullptr);
	char * getString0();
	char * getString1();
	void enableExtLed();
	void enableLed(uint8_t index, bool value);
	void setMaskLed(uint32_t value);
	void setExtMaskLed(uint64_t value);
	uint32_t getMaskLed();
	uint64_t getExtMaskLed();
	void setValueLed(uint8_t index, bool value);
	void setRSSILed(uint8_t value);
	uint8_t getRSSILed();
	void setVoltageLed(uint8_t value);
	uint8_t getVoltageLed();
	void setBlock(bool value);
	bool getBlock();
	void setBuzzer(bool value);
	bool getBuzzer();
	void setModule(Module *ptr);
	ModuleControl(Module *ptr, byte input_key=255, byte out_indicate=255);
	ModuleControl(uint32_t id_data=CAN_BASE_RADIO_DATA);
};
