#pragma once

#include "Device.h"
#include "InputChannel.h"
#include "Bootloader.h"
#include "ClockSource.h"

enum class UCcommandsID : ushort
{
	BootloaderAcknowledged = 0x340,
	BootloaderNotAcknowledged,
	BootloaderCheckFailed,
	BootloaderAbort,
	BootloaderReadyToUpdate,
	BootloaderUpdate,
	BootloaderFirmwareUpdated,
	GetDeviceInfoCommand = 0x3F9,
	ClearEEPROMCommand = 0x03F7,
	ClearFlashCommand = 0x03F5
};

enum class UCparametersID : ushort
{
	Input_0 = 0x100,
	Input_1,
	Input_2,
	Input_3,
	Input_4,
	Input_5,
	Input_6,
	Input_7,
	Input_8,
	Input_9,
	Input_10,
	Input_11,
	Input_12,
	Input_13,
	Input_14,
	Input_15,
	Input_16,
	Input_17,
	Input_18,
	Input_19,
	Input_20,
	Input_21,
	Input_22,
	Input_23,
	Input_24,
	Input_25,
	Input_26,
	Input_27,
	Input_28,
	Input_29,
	Input_30,
	Input_31,
	Input_32,
	Input_33,
	Input_34,
	Input_35,
	Input_36,
	Input_37,
	Input_38,
	Input_39,
	Input_40,
	Input_41,
	Input_42,
	Input_43,
	Input_44,
	Input_45,
	Input_46,
	Input_47,
	Input_48,
	Input_49,
	Input_50,
	Input_51,
	Input_52,
	Input_53,
	Input_54,
	Input_55,
	Input_56,
	Input_57,
	Input_58,
	Input_59,
	Input_60,
	Input_61,
	Input_62,
	Input_63,
	Input_64,
	Input_65,
	Input_66,
	Input_67,
	Input_68,
	Input_69,
	Input_70,
	Input_71,
	Input_72,
	Input_73,
	Input_74,
	Input_75,
	Input_76,
	Input_77,
	Input_78,
	Input_79,
	OutputSectionStart,
	PWMenable = OutputSectionStart,
	PWMdisable,
	PWMduty_mask,
	PWMduty_0,
	PWMduty_1,
	PWMduty_2,
	PWMduty_3,
	PWMduty_4,
	PWMduty_5,
	PWMduty_6,
	PWMduty_7,
	PWMduty_8,
	PWMduty_9,
	PWMduty_10,
	PWMduty_12,
	PWMduty_13,
	PWMduty_14,
	PWMduty_15,
	PWMstatus,
	PWMcurrentEnable,
	PWMcurrentDisable,
	PWMcurrent_0,
	PWMcurrent_1,
	PWMcurrent_2,
	PWMcurrent_3,
	PWMcurrent_4,
	PWMcurrent_5,
	PWMcurrent_6,
	PWMcurrent_7,
	PWMcurrent_8,
	PWMcurrent_9,
	PWMcurrent_10,
	PWMcurrent_12,
	PWMcurrent_13,
	PWMcurrent_14,
	PWMcurrent_15,
	DiscreteEnable,
	DiscreteDisable,
	DiscreteState,
	DiscreteStatus,
	DiscreteCurrentEnable,
	DiscreteCurrent_0,
	DiscreteCurrent_1,
	DiscreteCurrent_2,
	DiscreteCurrent_3,
	DiscreteCurrent_4,
	DiscreteCurrent_5,
	DiscreteCurrent_6,
	DiscreteCurrent_7,
	DiscreteCurrent_8,
	DiscreteCurrent_9,
	DiscreteCurrent_10,
	DiscreteCurrent_11,
	DiscreteCurrent_12,
	DiscreteCurrent_13,
	DiscreteCurrent_14,
	DiscreteCurrent_15,
	DiscreteCurrent_16,
	DiscreteCurrent_17,
	DiscreteCurrent_18,
	DiscreteCurrent_19,
	DiscreteCurrent_20,
	DiscreteCurrent_21,
	DiscreteCurrent_22,
	DiscreteCurrent_23,
	DiscreteCurrent_24,
	DiscreteCurrent_25,
	DiscreteCurrent_26,
	DiscreteCurrent_27,
	DiscreteCurrent_28,
	DiscreteCurrent_29,
	DiscreteCurrent_30,
	DiscreteCurrent_31,
	OutputSectionEnd = DiscreteCurrent_31,
	InputVoltage = 0x240,
	BootloaderStart = 0x340,
	BootloaderFirmwareUpdateRequest = BootloaderStart,
	BootloaderRequestPage,
	BootloaderNextPage,
	BootloaderEnd = BootloaderNextPage,
	McuType	= 0x03F3,
	ClearFlashProgress = 0x03F4,
	ClearEEPROMProgress = 0x03F6,
	ClockSourceConfiguration = 0x3F8,
	DeviceUID = 0x3FA,
	LibraryVersion = 0x3FB,
	BuildType=0x3FC,
	OnlinePing=0x3FD,
	NameProject=0x3FE,
	VersionProject = 0x3FF
};

union Version {

	uint32_t flatten;

	struct __attribute__((packed)) {
		BUILD_TYPE buldType;
		uint8_t buildNumber;
		uint8_t minorVersion;
		uint8_t majorVersion;
	};
};

class UCdevice : public Device
{
	friend class ADCt;
	friend class RGOneWire;

	void inputSettingsPrepare(InputChannelSettings &setting);
	bool validateInputSettings(byte channel, InputChannelSettings &settings);

	private:
	static void onSendingSystemInfo();
	static void sendClockSource();

	static uint8_t EEPROMProgress;
	static uint8_t FlashProgress;

	static void onClearEEPROM();
	static void onClearFlash();

	static void clearEEPROM();
	static void sendEEPROMClearProgress();

	static void clearFlash();
	static void sendFlashClearProgress();

protected:
	float vIn;
	Bootloader firmware;
	void sendUCparameter(UCparametersID idParam);
	void sendUCcommand(UCcommandsID idComm);
	virtual void deviceSegmentPrepare();
	virtual void deviceSegmentReceived(Segment<uint> *segment) final;
	virtual void inputChannelSet(byte channel, InputChannelSettings &setting);
	virtual void inputChannelReset(byte channel);
	virtual void bootHandler(UCparametersID idParam){};
	virtual void bootUpdate(){};

public:
	UCdevice(byte group = 0, bool listenMode = false);
	InputChannel input[24];
	ushort outputStatus[3];
	void inputChannelDisable(byte channel);
	void inputChanneldeletePtr(byte channel);
	bool inputChannelEnable(byte channel, InputChannelSettings &setting);
	float getInputVoltage();
	bool validateFirmwareFile(byte *buf, uint size, uint &crc);
	bool updateFirmware(byte *buf, uint size, bool restart = false);
	BootloaderStatus getUpdateFirmwareStatus(byte &percentage);
	Version getLibraryVersion();
	ClockSource getClockSource();
};
