#pragma once

#include "UCdevice.h"
#include "SingleTimer.h"

extern "C"
{
	void TIM8_TRG_COM_TIM14_IRQHandler();
}

class Timer14 : public SingleTimer
{
	friend class Periphery;
	friend void TIM8_TRG_COM_TIM14_IRQHandler();

	static Timer14 *module;

	Timer14(UCdevice &dev);
};
