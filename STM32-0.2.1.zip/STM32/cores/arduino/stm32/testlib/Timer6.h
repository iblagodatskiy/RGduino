#pragma once

#include "Types.h"
#include "Config.h"

extern "C" void TIM6_DAC_IRQHandler();

class Timer6
{
	friend void TIM6_DAC_IRQHandler();
	static byte cnt;
	static void(*handler[TIM6_MAX_CALLBACK])();
	static ushort delay[TIM6_MAX_CALLBACK];
public:
	bool add(ushort us, void (*link)());
	Timer6();
};
