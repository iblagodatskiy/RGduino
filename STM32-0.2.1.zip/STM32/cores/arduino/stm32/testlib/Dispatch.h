#ifndef DISPATCH_H_
#define DISPATCH_H_
#include <stdint-gcc.h>

struct Dispatch {
		bool isEnabled;
		uint16_t intervalMs;
		uint32_t lastSendingTime;

		Dispatch() {
			isEnabled = false;
			intervalMs = 100;
			lastSendingTime = 0;
		}
};

#endif /* DISPATCH_H_ */
