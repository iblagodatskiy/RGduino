#pragma once

#include "Timer.h"
#include "Manager.h"
#include "InputControl.h"

class RGOneWire : System::Timer, System::Manager
{
public:
	enum class Mode
	{
		Slave,
		Master
	};
	enum class Status
	{
		Disabled,
		Pending,
		TransmitFail,
		ReceiveFail,
		TransmitOK,
		ReceiveOK
	};

	RGOneWire(byte chan);

	Status getStatus();
	bool send(byte *buf, byte len);
	bool receive(byte *buf, byte len);
private:
	enum class Process
	{
		Synchronization,
		Synchronized,
		Transmit,
		Receive
	}process;

	enum class Phase
	{
		Sync,
		Command,
		Length,
		Data,
		Crc,
		ACK
	}phase;

	enum class Control
	{
		NoCommand,
		Set,
		Reset
	}control;

	byte channel;
	ushort counter;
	byte buffer[8];
	byte *link;
	byte length;
	ushort crc;
	byte crcTemp;
	bool level;
	bool checkCrc;
	Status status;
	InputControl::Setting iosetting;

	virtual void tick_1000Hz() override;
	virtual void manager() override;

	void selectDirection(byte val, byte bit);
	void set();
	void reset();
};
