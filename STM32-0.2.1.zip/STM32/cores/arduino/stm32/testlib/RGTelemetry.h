/*
 * RGTelemetry.h
 *
 *  Created on: 17 февр. 2022 г.
 *      Author: IAleksandrov
 */

#ifndef RGTELEMETRY_H_
#define RGTELEMETRY_H_

#include "Device.h"

class RGTelemetry : public Device
{
  private:
    struct StatusTipedef;
    struct LatTipedef;
    struct LonTipedef;
  public:
    RGTelemetry();
    Parameter* getParameters();
};

#endif /* RGTELEMETRY_H_ */
