#pragma once

#include "stdint.h"
#include "CANContainer.h"

//----------------------���������-------------------------------------
enum
{
	JOY_1_AXIS_Y,
	JOY_2_AXIS_Y,
	JOY_3_AXIS_Y,
	JOY_4_AXIS_Y,
	JOY_5_AXIS_Y,
	JOY_6_AXIS_Y
	//
};

//-------------------------�����--------------------------------------
typedef enum{
	INPUT_BIND_RADIO_PIN,//51
	INPUT_WATER_FAIL//49
}INPUTS;

//---------------------------����-------------------------------------
typedef enum
{
	OUTPUT_JOY_1_PWM,//46
	OUTPUT_JOY_2_PWM,//29
	OUTPUT_JOY_3_PWM,//27
	OUTPUT_JOY_4_PWM,//9
	OUTPUT_JOY_5_PWM,//24
	OUTPUT_JOY_6_PWM,//22
	OUTPUT_KEY_26_PWM,
	OUTPUT_KEY_29_PWM
	// OUTPUT_JOY_7_PWM,//20
	// OUTPUT_JOY_8_PWM//18
}PWM_OUTPUTS;
//--------------------------------------------------------------


typedef struct
{
	uint16_t PWM[12];

	bool vnvdPressureReset = false;
	bool engineRPMReset = false;

	bool upperGate = false;
	bool fillingGate = false;
	bool drainGate = false;

	bool vnvdHoseUp = false;
	bool vnvdHoseDown = false;

	bool rpmUp = false;
	bool rpmDown = false;

	bool vacuumUp = false;
	bool vacuumDown = false;

	bool vnvdPump = false;

	bool emergency = false;

	bool s1Up = false;
	bool s1Down = false;

	bool s5Up = false;
	bool s5Down = false;

	bool waterFailure = false;
}SYSTEM_STR;

typedef struct
{
	int16_t axis_0;
	int16_t axis_1;
	bool key_0;
	bool key_1;
	bool key_2;
}MESSAGE;
