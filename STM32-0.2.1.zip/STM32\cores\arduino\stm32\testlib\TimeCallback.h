#pragma once
#include "Timer.h"

#define PROTOCOL_CONTAINER_CALLBACK(callback) System::CountdownCall::enable(0,[]{callback;})

namespace System
{
	class PeriodicCall : Timer
	{
	public:
		static bool enable(uint period, void (*link)(), bool start = false)
		{
			return Timer::enable(period, link, true);
		}
		static bool disable(void (*link)())
		{
			return Timer::disable(link);
		}
	};

	class CountdownCall
	{
	public:
		static bool enable(uint period, void(*link)(), bool start = false)
		{
			return Timer::enable(period, link, false);
		}
		static bool disable(void (*link)())
		{
			return Timer::disable(link);
		}
	};
}
