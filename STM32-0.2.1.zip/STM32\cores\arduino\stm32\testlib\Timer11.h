#pragma once

#include "UCdevice.h"
#include "SingleTimer.h"

extern "C"
{
	void TIM1_TRG_COM_TIM11_IRQHandler();
}

class Timer11 : public SingleTimer
{
	friend class Periphery;
	friend void TIM1_TRG_COM_TIM11_IRQHandler();

	static Timer11 *module;

	Timer11(UCdevice &dev);
};
