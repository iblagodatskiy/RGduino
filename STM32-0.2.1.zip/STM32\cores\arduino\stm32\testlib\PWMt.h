#pragma once

#include "Types.h"
#include "CurrentMeasure.h"
#include "Config.h"
#include "stdint.h"
#if (OVER_LOAD_CONTROL ==1)
#include "OverLoadControl.h"
#else
#include "ShiftRegControl.h"
#endif // OVER_LOAD_CONTROL
#include "JoyParam.h"
#include "Dispatch.h"

#define PWM_COUNT	8U

class PWMt: CurrentMeasure
#if (OVER_LOAD_CONTROL ==1)
		, public OverLoadControl
#else
		, Hardware::ShiftRegControl
#endif // OVER_LOAD_CONTROL
{
	private:

		struct PwmDispatch {
			Dispatch duty;		// ����������� ������ �������� ����������
			Dispatch current;	// ����������� ������ �������� ����
		};

		struct PwmSettings {
			PwmDispatch dispatch;
		};

		struct PwmsSettings {
			PwmSettings channels[PWM_COUNT];
			Dispatch statusDispatch;
		};

		static byte enabled;
		static bool enable_Bezier;
		// first index - num channel
		//second index -
		//0-input scale min
		//1-input scale max
		//2-out scale min
		//3-out scale max
		static int16_t scale[8][6];
		enum SCALE {
			IN_MIN = 0, IN_MAX, OUT_MIN, OUT_MAX, IN_THRHD_MIN, IN_THRHD_VAL
		};
	public:

		PwmsSettings settings;

		PWMt();
		static bool enable(byte chan, bool currentMeasure = false);
		static void enableMask(byte mask, bool currentMeasure = false);
		static bool enableBezier(byte mask);
		static bool enableCurrentMeasure(byte chan);
		static bool setFlow(byte chan, byte flow);
		static bool setTurtle(byte chan, byte turtle);
		static bool setFlowMask(byte mask, byte flow);
		static bool setTurtleMask(byte mask, byte turtle);
		static bool setZero(byte chan, byte zero_offset);
		static bool enableCurrentMeasureMask(byte mask);
		static bool getEnabled(byte chan);
		static byte getEnabledMask();
		static void disable(byte chan);
		static void setAutoReload(byte chan, uint16_t reload);
		static void disableMask(byte mask);
		static bool disableCurrentMeasure(byte chan);
		static void disableCurrentMeasureMask(byte chan);
		static bool set(byte chan, ushort duty, bool is_turtle = false, bool use_bezier = false);
		static bool setMask(byte mask, ushort duty);
		static ushort get(byte chan);
		static float getCurrent(byte chan);
		byte getStatus();
		bool getStatus(byte chan);
		bool setWithScale(byte chan, int16_t duty);
		void setScale(byte chan, ushort inp_min, ushort inp_max, ushort out_min = 0, ushort out_max = 1000, ushort threshold_min = 0,
				ushort threshold_val = 0);
		void setPrescale(uint32_t frequency);
};
