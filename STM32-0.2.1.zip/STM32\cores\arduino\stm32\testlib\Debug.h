#pragma once

#include "Types.h"
#include "stdio.h"

void hexToSym(byte data, char *result);
