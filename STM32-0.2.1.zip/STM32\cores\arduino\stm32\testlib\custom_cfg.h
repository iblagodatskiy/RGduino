#pragma once

//*********************
// Version Controller:
//*********************
#define verMajor 2
#define verMinor 2
#define verType 5
#define verSubMinor 5
//verType:
//	1-base; 
//	2-Actuator instead of Zummer;
//	3-full operation on PWM and Actuator instead of Zummer.
//	4-for BryanskSelMash controller
//	5-(like 3) for TWINS Controllers.

#define TWINS_CONTROLLERS	0

#define CUSTOM_CFG_USE

// RG PROTOCOL CUSTOM PER-PROJECT SETTINGS
#define CUSTOM_RG_DEVICE_GROUP		0

//#if (TWINS_CONTROLLERS == 0)
//#define CUSTOM_J1939_COMPATIBILITY	0
//#endif // (TWINS_CONTROLLERS == 0)
#define CUSTOM_J1939_COMPATIBILITY	1

//#define CUSTOM_BRAIN_ABSENCE_DELAY	2
//��� ���� ����� ���������� DELAY=2, ��� ����� ������ � ������� DMA - DELAY=1

#define CUSTOM_SIMPLE_LED			1
#define CUSTOM_SD_CARD				0

#define CUSTOM_CPU_LOAD				0
#define CUSTOM_VOLTAGE_CONTROL		1
#define CUSTOM_OVER_LOAD_CONTROL	0

#define CUSTOM_WATCHDOG				1
#define CUSTOM_RTC_TIME				1

#define CUSTOM_DEBUG_STACK			0

#define CUSTOM_TEST_IO				1

#define DEBUG_FR					0
#define CUSTOM_MODBUS_PARAMS_NUMBER 25

#define CUSTOM_RS485_TERMINATOR_ENABLE 0

//#define CUSTOM_MODBUS_USE_LED	0

//#define CUSTOM_TEST_IO_SELF_TEST 	1

//#define CUSTOM_COMMANDS_MAX_NUMBER	44
//#define CUSTOM_COMMANDS_MAX_PENDING	44
//#define CUSTOM_PARAMETER_SIZE			262
