#pragma once

#include "Types.h"
#include "DigitalFilter.h"
#include "FourierTransform.h"

extern const uint adcRange;

class InputChannelSettings
{
	friend class Periphery;
	friend class ADCt;
public:
	enum class Type : byte
	{
		Disabled,
		DiscreteUp, // 0.5 from input voltage after divider
		DiscreteDown,
		Voltage,
		CurrentLoop,
		Resistance,
		Counter,
		Frequency,
		AlternateFunction,
		FrequencyAnalog
	}type;

	enum class Amplitude : byte
	{					//Full measurement range;
		High,			//14.65v;	Resistance - max
		Medium,			//13v;		Resistance - max 66		kOm
		Low,			//4.94v;	Resistance - max 1353	Ohm
		Digit,			//3.3v;		Resistance - max 708	Ohm
		Amplified		//0.01v - threshold;
	}amplitude;

	struct Hysteresis
	{
		bool overPoint;
		enum class Direction : bool
		{
			Positive,
			Negative
		}direction;
		union
		{
			uint timing;// for hysteresis with frequency channels
			float analog;
		}up, down;
	}hysteresis;

	struct Dispatch
	{
		enum class Type : byte
		{
			Disabled,
			Periodic,
			IfChanged,
			Both
		}type;
		ushort period;
		ushort counter;
		bool required;
		void operator = (ushort per) { period = per; }
	}dispatch;

	struct Update
	{
		ushort period;
		ushort counter;
		bool required; //���� ����������� ��������� �������� (����� ��������� ��� ���������)
		enum class FastMode : byte
		{
			Disabled,
			Enabled,	//~1000Hz measurement
			Ultra		// maximum speed measurement
		}fastMode;
		void operator = (ushort per) { period = per; }
	}update;

	/*
	 * �������� ������� ��������� ��� ������ ��������
	 */
	struct Divider
	{
		enum class Type : byte
		{
			Auto,
			Manual,		//from 1 to 8
		}type;
		enum class Prescale : byte //from 1 to 8
		{
			Presc1,
			Presc2,
			Presc4,
			Presc8,
		}prescale;
		void operator = (Divider::Prescale psc) { prescale = psc; }
	}divider;

	enum class Mode : byte
	{
		Numerical,
		Discrete
	}mode;

	struct DigitalFilter
	{
		enum class Type : byte
		{
			Disabled,
			Average,
			Threshold,// Dont know how it works
			Following
		}type;
		ushort length;
		::DigitalFilter *ptr;
		bool newData;
		float measurement;
	}digitalFilter;

	struct FourierTransform
	{
		enum class Type : byte
		{
			Disabled,
			Fourier,
			PeakDetect
		}type;
		ushort length;
		::FourierTransform *ptr;
		bool newData;
		float measurement;

		uint16_t *pBuff;
	}fourierTransform;

	enum class LowPassFilter : byte
	{
		Disabled,
		Low,
		Medium,
		High
	}LPF;

	enum class Error : byte
	{
		Disabled,
		WireBreak
	}error;

	/*
	 * ����� ������� �� ���� ������ �������
	 */
	enum class TypeFront
	{
		CALL_NONE=0,
		CALL_RISING,
		CALL_FALLING,
		CALL_BOTH,

	};
	/*
	 * ��� ������
	 */
	enum class TypeKey
	{
		KEY_INVERSE=0,
		KEY_NORMAL_CLOSE,
		KEY_NORMAL_OPEN
	};

	struct DiscretKeySettings {
		void (*callback)();
		TypeFront type_front;
	}discret_callback;

	InputChannelSettings();
	InputChannelSettings(InputChannelSettings::Type typeCh, ushort periodCh);

	virtual void clear();
	bool isAnalog();
	bool isTiming();
	bool isFreqAnalog();
protected:
	enum class RangeAdjust
	{
		NoNeed,
		Up,
		Down
	}rangeAdjustment;
	struct ProcessAcceleration
	{
		bool analog;
		bool freqAnalog;
		byte fastModeMask;
	}procAccel;
	static uint enMask;
};

class InputChannel final : protected InputChannelSettings
{
	friend class UCdevice;
	friend class ADCt;
	friend class SingleTimer;
	friend class DoubleTimer;
	friend class DoubleTimerExtended;
	friend class Periphery;
	friend class RGOneWire;
	void operator = (InputChannelSettings &setting);
	ushort raw;
public:
	union
	{
		bool Discrete;
		float Voltage;
		float CurrentLoop;
		float Resistance;
		float Frequency;
		uint Counter;
	}value;

	void setCallback(TypeFront _type_front, void (*_callback)()) {
		discret_callback.callback = _callback;
		discret_callback.type_front = _type_front;
	}
	bool newData;
	bool hasChanged;
	InputChannelSettings::Error getStatus();
	virtual void clear();
	bool isEnabled();

	ushort getRaw() 	{ return raw; }
	bool isZeroValue() 	{ return raw == 0; }
	bool isMaxValue() 	{ return raw == adcRange - 1; }

	void setUpdate(ushort val);
	InputChannelSettings* getSettings() {
		return this;
	}
};
