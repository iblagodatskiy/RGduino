#pragma once
#include "Manager.h"
#include "Timer.h"
#include "Types.h"
#include "Parameters.h"
#include "Config.h"
#include "FreeRTOS.h"
#include "semphr.h"

#ifndef RG_DEVICE_GROUP
#error "The device group number must be declared"
#elif (RG_DEVICE_GROUP > 31) || (RG_DEVICE_GROUP < 0)
#error "The device group number must be less than 32"
#endif


class RGprotocol;

enum class DeviceType : byte
{
	BroadCast = 0x00,

	ExternalComputer,		// 01
	Controller,				// 02
	Reserved1,				// 03
	Reserved2,				// 04
	WirelessModule,			// 05
	Reserved4,				// 06
	
	Mask = 0x07
};

struct DeviceID
{
	DeviceType type : 3;
	byte group		: 5;

	bool operator==(DeviceID check)
	{
		return (check.group == group) && (check.type == type);
	}
	bool operator!=(DeviceID check)
	{
		return (check.group != group) || (check.type != type);
	}
};

constexpr DeviceID broadcastID()// all 8 bits = 0 (0x00)
{
	DeviceID id{DeviceType::BroadCast, 0};
	return id;
}

constexpr DeviceID maskID()// all 8 bits = 1 (0xFF)
{
	DeviceID id{DeviceType::Mask, 31};
	return id;
}

struct CANpackID
{
	DeviceID source;
	DeviceID destination;
};

enum class SegmentType : byte
{
	Get,
	Set,
	Single,
	Double,
	Quad,
	Array,
	Command,
	Error
};

struct SegmentHeader
{
	ushort		ID		: 13;
	SegmentType	type	: 3;
}__attribute__((packed));

template <typename T>
struct Segment : SegmentHeader
{
	T data;
}__attribute__((packed));


struct CANbufTransmitter
{
	bool		free;
	ushort 		paramIndex;
	uint32_t 	lasttime;
	ushort		counter;
	ushort		length;
	DeviceID	destination;
	byte		buf[BUFFER_MAX_SIZE];
	RGprotocol	*owner;
};

enum class BufferOwner : byte
{
	Free,
	CAN,
	Handler
};

struct CANbufReceiver
{
	BufferOwner	owner;
	bool		active;
	bool		newMessage;
	bool		timeout;
	uint		CRCval;
	ushort		length;
	ushort		counter;
	byte		buf[BUFFER_MAX_SIZE];
};

struct MessageHeader
{
	ushort	length;
	byte	key;
	byte	protection;
	uint	CRCval;
};

struct ExistingDevice
{
	byte count;
	uint busyId[7];// flags for protection from same device types with same ID's; 7 types for 32 devices
	RGprotocol *ptr[EXISTING_DEVICES_MAX_NUMBER];
};

class RGprotocol : public ManualInstructions, protected System::Timer, private System::Manager
{
	friend void sendMessageBody();
	friend void abortTransmitting();
	friend bool CANpackReceived(ushort id, byte *CANpack);
	friend class Device;

	typedef struct
	{
		DeviceID idNodeWait;
		uint32_t timeWait;
		uint32_t current_time;
		bool isConnect;
	}NodeWait;

	DeviceID id;

	NodeWait nodewait;

	CANbufReceiver receiver;
	static xSemaphoreHandle xMutex;

	void CANpackHandler(byte *CANpack);
	bool insertParameter(Parameter &parameter);
	bool messagePrepare(MessageHeader &header);
	void messageReceived();

	virtual void tick_1Hz() override = 0;
	void manager() final;
	RGprotocol(DeviceType type, byte group, bool silentMode);
protected:
	static CANbufTransmitter transmitter;
	static RGprotocol *host;
	static ExistingDevice deviceCount;
	static byte CANstallCounter;

	bool groupIsFree(DeviceType type, byte group);
	bool clearGroup(DeviceType type, byte group);
	bool setGroup(DeviceType type, byte group);
	virtual void systemSegmentPrepare(){};
	virtual void deviceSegmentPrepare(){};
	virtual void systemSegmentReceived(Segment<uint> *segment){};
	virtual void deviceSegmentReceived(Segment<uint> *segment){};
public:
	DeviceID getID();
	bool setGroup(byte group);
	void setNodeWait(DeviceID idNode, uint32_t time_wait);//time_wait in ms
	bool getNodeWait();
};

void sendMessageBody();
void abortTransmitting();
bool CANpackReceived(ushort id, byte *CANpack);
