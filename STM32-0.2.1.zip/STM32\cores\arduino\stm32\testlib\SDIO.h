#pragma once
#include "Types.h"

namespace Hardware
{
	// SDIO power supply control bits
	#define SDIO_PWR_OFF           0x00 // Power off: the clock to card is stopped
	#define SDIO_PWR_ON            0x03 // Power on: the card is clocked

	// SDIO clock divider
	#define SDIO_CLK_DIV_187K      0xFF // SDIO clock 187.5kHz (48MHz / (0xFF + 2) = 400kHz)

	// SDIO clocks for initialization and data transfer
	#define SDIO_CLK_DIV_INIT      SDIO_CLK_DIV_187K // SDIO initialization frequency (400kHz)
	#define SDIO_CLK_DIV_TRAN      SDIO_CLK_DIV_187K  // SDIO data transfer 24MHz

	// SDIO CMD response type
	#define SDIO_RESP_NONE         0x00                // No response
	#define SDIO_RESP_SHORT        SDIO_CMD_WAITRESP_0 // Short response
	#define SDIO_RESP_LONG         SDIO_CMD_WAITRESP   // Long response

	// SD commands  index
	#define SD_CMD_GO_IDLE_STATE          ((byte)0)
	#define SD_CMD_SEND_OP_COND           ((byte)1)  // MMC only
	#define SD_CMD_ALL_SEND_CID           ((byte)2)  // Not supported in SPI mode
	#define SD_CMD_SEND_REL_ADDR          ((byte)3)  // Not supported in SPI mode
	#define SD_CMD_SEL_DESEL_CARD         ((byte)7)  // Not supported in SPI mode
	#define SD_CMD_HS_SEND_EXT_CSD        ((byte)8)
	#define SD_CMD_SEND_CSD               ((byte)9)
	#define SD_CMD_SEND_CID               ((byte)10)
	#define SD_CMD_READ_DAT_UNTIL_STOP    ((byte)11) // Not supported in SPI mode
	#define SD_CMD_STOP_TRANSMISSION      ((byte)12)
	#define SD_CMD_SEND_STATUS            ((byte)13)
	#define SD_CMD_GO_INACTIVE_STATE      ((byte)15) // Not supported in SPI mode
	#define SD_CMD_SET_BLOCKLEN           ((byte)16)
	#define SD_CMD_READ_SINGLE_BLOCK      ((byte)17)
	#define SD_CMD_READ_MULT_BLOCK        ((byte)18)
	#define SD_CMD_WRITE_DAT_UNTIL_STOP   ((byte)20) // Not supported in SPI mode
	#define SD_CMD_WRITE_BLOCK            ((byte)24)
	#define SD_CMD_WRITE_MULTIPLE_BLOCK   ((byte)25)
	#define SD_CMD_PROG_CSD               ((byte)27)
	#define SD_CMD_SET_WRITE_PROT         ((byte)28) // Not supported in SPI mode
	#define SD_CMD_CLR_WRITE_PROT         ((byte)29) // Not supported in SPI mode
	#define SD_CMD_SEND_WRITE_PROT        ((byte)30) // Not supported in SPI mode
	#define SD_CMD_ERASE                  ((byte)38)
	#define SD_CMD_LOCK_UNLOCK            ((byte)42)
	#define SD_CMD_APP_CMD                ((byte)55)
	#define SD_CMD_READ_OCR               ((byte)58) // Read OCR register
	#define SD_CMD_CRC_ON_OFF             ((byte)59) // On/Off CRC check by SD Card (in SPI mode)

	// Following commands are SD Card Specific commands.
	// SD_CMD_APP_CMD should be sent before sending these commands.
	#define SD_CMD_SET_BUS_WIDTH          ((byte)6)  // ACMD6
	#define SD_CMD_SD_SEND_OP_COND        ((byte)41) // ACMD41
	#define SD_CMD_SET_CLR_CARD_DETECT    ((byte)42) // ACMD42
	#define SD_CMD_SEND_SCR               ((byte)51) // ACMD51

	// Pattern for R6 response
	#define SD_CHECK_PATTERN              ((uint)0x000001AA)

	// Argument for ACMD41 to select voltage window
	#define SD_OCR_VOLTAGE                ((uint)0x80100000)

	// Mask for errors in card status value
	#define SD_CS_ERROR_BITS              ((uint)0xFDFFE008) // All possible error bits
	#define SD_CS_OUT_OF_RANGE            ((uint)0x80000000) // The command's argument was out of allowed range
	#define SD_CS_ADDRESS_ERROR           ((uint)0x40000000) // A misaligned address used in the command
	#define SD_CS_BLOCK_LEN_ERROR         ((uint)0x20000000) // The transfer block length is not allowed for this card
	#define SD_CS_ERASE_SEQ_ERROR         ((uint)0x10000000) // An error in the sequence of erase commands occurred
	#define SD_CS_ERASE_PARAM             ((uint)0x08000000) // An invalid selection of write-blocks for erase occurred
	#define SD_CS_WP_VIOLATION            ((uint)0x04000000) // Attempt to write to a protected block or to the write protected card
	#define SD_CS_LOCK_UNLOCK_FAILED      ((uint)0x01000000) // Sequence or password error in lock/unlock card command
	#define SD_CS_COM_CRC_ERROR           ((uint)0x00800000) // The CRC check of the previous command failed
	#define SD_CS_ILLEGAL_COMMAND         ((uint)0x00400000) // Command not legal for the card state
	#define SD_CS_CARD_ECC_FAILED         ((uint)0x00200000) // Card internal ECC was applied but failed to correct the data
	#define SD_CS_CC_ERROR                ((uint)0x00100000) // Internal card controller error
	#define SD_CS_ERROR                   ((uint)0x00080000) // A general or an unknown error occurred during the operation
	#define SD_CS_STREAM_R_UNDERRUN       ((uint)0x00040000) // The card could not sustain data transfer in stream read operation
	#define SD_CS_STREAM_W_OVERRUN        ((uint)0x00020000) // The card could not sustain data programming in stream mode
	#define SD_CS_CSD_OVERWRITE           ((uint)0x00010000) // CSD overwrite error
	#define SD_CS_WP_ERASE_SKIP           ((uint)0x00008000) // Only partial address space was erased
	#define SD_CS_CARD_ECC_DISABLED       ((uint)0x00004000) // The command has been executed without using the internal ECC
	#define SD_CS_ERASE_RESET             ((uint)0x00002000) // An erase sequence was cleared before executing
	#define SD_CS_AKE_SEQ_ERROR           ((uint)0x00000008) // Error in the sequence of the authentication process

	// Card state (OCR[12:9] bits CURRENT_STATE)
	#define SD_STATE_IDLE                 ((byte)0x00) // Idle
	#define SD_STATE_READY                ((byte)0x01) // Ready
	#define SD_STATE_IDENT                ((byte)0x02) // Identification
	#define SD_STATE_STBY                 ((byte)0x03) // Stand-by
	#define SD_STATE_TRAN                 ((byte)0x04) // Transfer
	#define SD_STATE_DATA                 ((byte)0x05) // Sending data
	#define SD_STATE_RCV                  ((byte)0x06) // Receive data
	#define SD_STATE_PRG                  ((byte)0x07) // Programming
	#define SD_STATE_DIS                  ((byte)0x08) // Disconnect
	#define SD_STATE_ERROR                ((byte)0xFF) // Error or unknown state

	// Mask for ACMD41
	#define SD_STD_CAPACITY               ((uint)0x00000000)
	#define SD_HIGH_CAPACITY              ((uint)0x40000000)

	// Timeout for CMD0 or CMD8
	#define SDIO_CMD_TIMEOUT              ((uint)0x00010000)

	// SDIO timeout for data transfer ((48MHz / CLKDIV / 1000) * timeout_ms)
	#define SDIO_DATA_R_TIMEOUT           ((uint)((48000000 / (SDIO_CLK_DIV_TRAN + 2) / 1000) * 100)) // Data read timeout is 100ms
	#define SDIO_DATA_W_TIMEOUT           ((uint)((48000000 / (SDIO_CLK_DIV_TRAN + 2) / 1000) * 250)) // Date write timeout is 250ms

	// Trials count for ACMD41
	#define SDIO_ACMD41_TRIALS            ((uint)0x0000FFFF)

	// Bitmap to clear the SDIO static flags (command and data)
	#define SDIO_ICR_STATIC               ((uint)(SDIO_ICR_CCRCFAILC | SDIO_ICR_DCRCFAILC | SDIO_ICR_CTIMEOUTC | \
													  SDIO_ICR_DTIMEOUTC | SDIO_ICR_TXUNDERRC | SDIO_ICR_RXOVERRC  | \
													  SDIO_ICR_CMDRENDC  | SDIO_ICR_CMDSENTC  | SDIO_ICR_DATAENDC  | \
													  SDIO_ICR_DBCKENDC))

	// SDIO bus width
	#define SD_BUS_1BIT                   0 // 1-bit wide bus (SDIO_D0 used)
	#define SD_BUS_4BIT                   SDIO_CLKCR_WIDBUS_0 // 4-bit wide bus (SDIO_D[3:0] used)
	#define SD_BUS_8BIT                   SDIO_CLKCR_WIDBUS_1 // 8-bit wide bus (SDIO_D[7:0] used)
	class SDIOt
	{
	public:
		// Card type
		enum class CardType : byte
		{
			UNKNOWN,
			SDSC_V1,	// Standard capacity SD card v1.0
			SDSC_V2,	// Standard capacity SD card v2.0
			MMC,
			SDHC		// High capacity SD card (SDHC or SDXC)
		};
		// SD card description
		typedef struct
		{
			CardType	Type;			// Card type (detected by SD_Init())
			uint		Capacity;		// Card capacity (MBytes for SDHC/SDXC, bytes otherwise)
			uint		BlockCount;		// SD card blocks count
			uint		BlockSize;		// SD card block size (bytes), determined in SD_ReadCSD()
			uint		MaxBusClkFreq;	// Maximum card bus frequency (MHz)
			byte		CSDVer;			// SD card CSD register version
			ushort		RCA;			// SD card RCA address (only for SDIO)
			byte		MID;			// SD card manufacturer ID
			ushort		OID;			// SD card OEM/Application ID
			byte		PNM[5];			// SD card product name (5-character ASCII string)
			byte		PRV;			// SD card product revision (two BCD digits: '6.2' will be 01100010b)
			uint		PSN;			// SD card serial number
			ushort		MDT;			// SD card manufacturing date
			byte		CSD[16];		// SD card CSD register (card structure data)
			byte		CID[16];		// SD card CID register (card identification number)
			byte		SCR[8];			// SD card SCR register (SD card configuration)
		} SDCard_TypeDef;

		bool readBlock(uint addr, uint *pBuf, uint length);
		bool writeBlock(uint addr, uint *pBuf, uint length);
		bool getStatus();
		SDCard_TypeDef getSDcardInfo();
		static SDIOt & instance();
	protected:
		SDIOt();
	private:
		// SD functions result
		enum class Result : byte
		{
			Success,
			Timeout,
			CRCError,			// Computed CRC not equal to received from SD card
			ReadError,			// Read block error (response for CMD17)
			WriteError,			// Write block error (response for CMD24)
			WriteErrorInternal,	// Write block error due to internal card error
			Unsupported,		// Unsupported card found
			BadResponse,
			SetBlockSizeFailed,	// Set block size command failed (response for CMD16)
			UnknownCard,
			NoResponse,
			AddrOutOfRange,		// Address out of range
			WriteCRCError,		// Data write rejected due to a CRC error
			InvalidVoltage,		// Unsupported voltage range
			DataTimeout,		// Data block transfer timeout
			DataCRCFail,		// Data block transfer CRC failed
			RXOverrun,			// Receive FIFO overrun
			TXUnderrun,			// Transmit FIFO underrun
			StartBitError,		// Start bit not detected on all data signals
			AddrMisaligned,		// A misaligned address which did not match the block length was used in the command
			BlockLenError,		// The transfer block length is not allowed for this card
			EraseSeqError,		// An error in the sequence of erase commands occurred
			EraseParam,			// An invalid selection of write-blocks for erase occurred
			WPViolation,		// Attempt to write to a protected block or to the write protected card
			LockUnlockFailed,	// Error in lock/unlock command
			ComCRCError,		// The CRC check of the previous command failed
			IllegalCommand,		// Command is not legal for the the current card state
			CardECCFailed,		// Card internal ECC was applied but failed to correct the data
			CCError,			// Internal card controller error
			GeneralError,		// A general or an unknown error occurred during the operation
			StreamUnderrun,		// The card could not sustain data transfer in stream read operation
			StreamOverrun,		// The card could not sustain data programming in stream mode
			CSDOverwrite,		// CSD overwrite error
			WPEraseSkip,		// Only partial address space was erased
			ECCDisabled,		// The command has been executed without using the internal ECC
			EraseReset,			// An erase sequence was cleared before executing
			AKESeqError 		// Error in the sequence of the authentication process
		};
		// SD card response type
		enum class CardResponseType : byte
		{
			R1 = 0x01,
			R1b = 0x02,
			R2 = 0x03,
			R3 = 0x04,
			R6 = 0x05,	// (SDIO only)
			R7 = 0x06
		};

		bool initialized;
		SDCard_TypeDef SDCard;// SD card parameters

		Result cmd(byte cmd, uint arg, ushort resp_type);
		Result getError(uint cs);
		Result response(CardResponseType resp_type, uint *pResp);
		Result setBlockSize(uint block_size);
		Result getSCR(uint *pSCR);
		Result setBusWidth(uint BW);
		void printResult(Result result, char *str);
		void getCardInfo(void);
		Result stopTransfer(void);
		Result getCardState(byte *pStatus);
	};
}
