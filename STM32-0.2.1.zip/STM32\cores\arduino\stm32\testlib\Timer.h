#pragma once
#include "Types.h"
#include "Config.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "task.h"
#include "queue.h"

#define DWT_TIMER_INIT() portCONFIGURE_TIMER_FOR_RUN_TIME_STATS()
#define DWT_TIMER_CNT() portGET_RUN_TIME_COUNTER_VALUE()
//30MHZ APB->60MHz to timer
//frequency APB1
//32-bit counter
#define startTIM2Ticks(x)\
do {\
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;\
	TIM2->ARR = 0xFFFFFFFF-1;\
	TIM2->CNT = 0u;\
	TIM2->PSC = x-1;\
	TIM2->CR1 = TIM_CR1_ARPE;\
    TIM2->CR1 |= TIM_CR1_CEN;\
	TIM2->EGR = TIM_EGR_UG;\
}while(0)
#define getTIM2Ticks() TIM2->CNT
#define resetTIM2Ticks() TIM2->CNT=0
#define stopTIM2Ticks()TIM2->CR1 &= (~TIM_CR1_CEN)
#define runTIM2Ticks()TIM2->CR1 |= TIM_CR1_CEN
#define isEnableTIM2Ticks() (TIM2->CR1 & TIM_CR1_CEN)

//16-bit counter
#define startTIM7Ticks(x)\
do {\
	RCC->APB1ENR |= RCC_APB1ENR_TIM7EN;\
	TIM7->ARR = 0xFFFF-1;\
	TIM7->CNT = 0u;\
	TIM7->PSC = x-1;\
	TIM7->CR1 = TIM_CR1_ARPE;\
	TIM7->CR1 |= TIM_CR1_CEN;\
	TIM7->EGR = TIM_EGR_UG;\
}while(0)
#define getTIM7Ticks() TIM7->CNT
#define resetTIM7Ticks() TIM7->CNT=0
#define stopTIM7Ticks()TIM7->CR1 &= (~TIM_CR1_CEN)
#define runTIM7Ticks()TIM7->CR1 |= TIM_CR1_CEN
#define isEnableTIM7Ticks() (TIM7->CR1 & TIM_CR1_CEN)

//frequency APB2
//16-bit counter
#define startTIM8Ticks(x)\
do {\
	RCC->APB2ENR |= RCC_APB2ENR_TIM8EN;\
	TIM8->ARR = 0xFFFF-1;\
	TIM8->CNT = 0u;\
	TIM8->PSC = x-1;\
	TIM8->CR1 = TIM_CR1_ARPE;\
	TIM8->CR1 |= TIM_CR1_CEN;\
	TIM8->EGR = TIM_EGR_UG;\
}while(0)
#define getTIM8Ticks() TIM8->CNT
#define resetTIM8Ticks() TIM8->CNT=0
#define stopTIM8Ticks()TIM8->CR1 &= (~TIM_CR1_CEN)
#define runTIM8Ticks()TIM8->CR1 |= TIM_CR1_CEN

//frequency APB2
//16-bit counter
#define startTIM9Ticks(x)\
do {\
	RCC->APB2ENR |= RCC_APB2ENR_TIM9EN;\
	TIM9->PSC = x-1;\
	TIM9->ARR = 0xFFFF;\
	TIM9->CR1 = TIM_CR1_ARPE;\
	TIM9->CNT = 0u;\
	TIM9->DIER |= TIM_DIER_UIE;\
	TIM9->SR = 0;\
	TIM9->EGR = TIM_EGR_UG;\
}while(0)
#define getTIM9Ticks() TIM9->CNT
#define resetTIM9Ticks() TIM9->CNT=0
#define stopTIM9Ticks()TIM9->CR1 &= (~TIM_CR1_CEN)
#define runTIM9Ticks()TIM9->CR1 |= TIM_CR1_CEN
#define isEnableTIM9Ticks() (TIM9->CR1 & TIM_CR1_CEN)
#define startIrgTIM9()\
	TIM9->SR = 0;\
	NVIC_SetPriority(TIM1_BRK_TIM9_IRQn, 6);\
	NVIC_EnableIRQ(TIM1_BRK_TIM9_IRQn);\
	TIM9->CR1 |= TIM_CR1_CEN;\

namespace System
{
	extern "C"
	{
		void SysTick_Handler();// 1000 Hz
		void TIM1_BRK_TIM9_IRQHandler();
	}

	class Timer
	{
	public:
		enum class Type : byte
		{
			Inactive,
			_Period,
			_OneShot,
			_1000Hz,
			_100Hz,
			_50Hz,
			_10Hz,
			_1Hz,
			_1Min
		};
		Timer(Type t1 = Type::Inactive, Type t2 = Type::Inactive, Type t3 = Type::Inactive, Type t4 = Type::Inactive);
		~Timer();
		static void vTimerProcess(TimerHandle_t xTimer);
		static void vTimerOneShot(void *pvParameter1, uint32_t ulParameter2);
		static bool enable(uint32_t period, void(*link)(), bool is_reload=false, bool instant_start=false);
		static bool disable(void(*link)());
		static uint32_t getCurrentTimeMS();
		static uint16_t getCurrentTimeUS();
		static void Delay_us(uint16_t delay);
		static void Delay_ms(uint32_t delay);
	private:
		class Initializer
		{
		public:
			Initializer();
		}static initializer;

		struct timer {
			void (*link_func)()=nullptr;
			Timer * link_obj=nullptr;
			uint32_t period=0;
			bool is_obj=false;
			TimerHandle_t handle=nullptr;
			Type type=Type::Inactive;
			bool is_stoped=false;
		};
		static timer buf[TIMER_MAX_CNT];
		static byte cnt;

		friend void SysTick_Handler();
		virtual void tick_1Min(){};
		virtual void tick_1000Hz(){};
		virtual void tick_100Hz(){};
		virtual void tick_50Hz(){};
		virtual void tick_10Hz(){};
		virtual void tick_1Hz(){};
	protected:
		bool enable(Type t);
		bool disable(Type t);
	};
}


