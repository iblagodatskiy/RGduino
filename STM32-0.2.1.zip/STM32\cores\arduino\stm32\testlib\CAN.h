#pragma once

#include "CoreSettings.h"
#include "Types.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "typeinfo"

typedef enum
{
	SPEED_10kb = 0, SPEED_20kb, SPEED_50kb, SPEED_100kb, SPEED_125kb, SPEED_250kb, SPEED_500kb, SPEED_1000kb,
} CAN_SPEED;

namespace Hardware
{
#define CAN1_ID_EXT		(CAN1->sFIFOMailBox[0].RIR >> 3)
#define CAN1_ID_STD		(CAN1->sFIFOMailBox[0].RIR >> 21)
#define CAN1_RTR		((CAN1->sFIFOMailBox[0].RIR >> 1) & 1)
#define CAN1_IDE		((CAN1->sFIFOMailBox[0].RIR >> 2) & 1)
#define CAN1_DLC		(CAN1->sFIFOMailBox[0].RDTR & 0x0F)
#define CAN1rxData		((byte *)(&CAN1->sFIFOMailBox[0].RDLR))
#define CAN1_Data_L		(CAN1->sFIFOMailBox[0].RDLR)
#define CAN1_Data_H		(CAN1->sFIFOMailBox[0].RDHR)

#define CAN2_ID_EXT		(CAN2->sFIFOMailBox[1].RIR >> 3)
#define CAN2_ID_STD		(CAN2->sFIFOMailBox[1].RIR >> 21)
#define CAN2_RTR		((CAN2->sFIFOMailBox[1].RIR >> 1) & 1)
#define CAN2_IDE		((CAN2->sFIFOMailBox[1].RIR >> 2) & 1)
#define CAN2_DLC		(CAN2->sFIFOMailBox[1].RDTR & 0x0F)
#define CAN2rxData		((byte *)(&CAN2->sFIFOMailBox[1].RDLR))
#define CAN2_Data_L		(CAN2->sFIFOMailBox[1].RDLR)
#define CAN2_Data_H		(CAN2->sFIFOMailBox[1].RDHR)
#define CAN_INIT_TIMEOUT   ((uint)0x00010000)

extern "C"
{
void CAN1_TX_IRQHandler();
void CAN1_RX0_IRQHandler();
void CAN2_TX_IRQHandler();
void CAN2_RX1_IRQHandler();
}

enum class CANfilterMode
	: byte
	{
		Mask, List
};

enum class CANfilterScale
	: byte
	{
		_11bit, _29bit
};
enum class TypeCallback
	: byte
	{
		_none, _std, //byte *buf, byte dlc
	_ext //byte *buf, byte dlc, uint32_t id
};
typedef void (*Callback_data)(byte *buf, byte dlc);
typedef void (*Callback_data_ext)(uint32_t id, byte *buf, byte dlc);
struct Callback_CAN
{
	void *handler;
	TypeCallback type_call;
	uint id;
	uint mask;
	CANfilterMode mode;
	CANfilterScale scale;
	bool is_active;
};

struct FilterDestination
{
	byte index :5;
	byte position :1;
};

struct CAN_packet
{
	uint32_t ID;
	bool IDE;
	uint8_t DLC;
	uint8_t data[8];
}__attribute__ ((packed));

class CANt
{
	friend class Timer;
	friend class Manager;
public:
	struct FilterSettings
	{
		byte CANnum;
		CANfilterMode mode;
		CANfilterScale scale;
		uint id;
		uint mask;
	};
	bool changeFilter(FilterSettings from, FilterSettings to);
	void sendPack(uint _ID, bool ext, byte *data, byte dataLen);
	void sendPack(uint _ID, byte *data, byte dataLen, bool ext=true);
private:
	friend void CAN2_RX1_IRQHandler();
	friend void CAN1_RX0_IRQHandler();
	friend void CAN1_TX_IRQHandler();
	friend void CAN2_TX_IRQHandler();

	static uint filterUtilization[4]; // for monitoring busy quarters of filter

	bool findFilter(FilterDestination &destination, FilterSettings settings);
	void moveFilter(byte from, byte to);
	void deleteFilter(FilterSettings settings);

protected:
	QueueHandle_t queue_can_tx;
	QueueHandle_t queue_can_rx;
	static Callback_CAN callback1[108]; // 27 (free banks) * 4 (16 bit) = 108
	static Callback_CAN callback2[108]; // 27 (free banks) * 4 (16 bit) = 108
	static byte idIndex1;
	static byte idIndex2;
	static byte dlc_tmp1;
	static byte dlc_tmp2;
	static byte data_tmp1[8];
	static byte data_tmp2[8];
	static uint32_t last_time_rx_can1;
	static uint32_t last_time_rx_can2;
	template<typename T>
	bool addFilt(byte CANnum, uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale, T handler)
	{
		if (handler != nullptr && typeid(handler) != typeid(Callback_data) && typeid(handler) != typeid(Callback_data_ext))
		{
			return false;
		}
		if (CANnum != 1 && CANnum != 2)
			return false;

		bool noSpace = true; // if there is no free space for new id
		signed char turnOn = -1; // if need to activate some register
		ushort id = _ID; // for 11bit id
		ushort msk = mask; // for 11bit id

		CAN1->FMR |= CAN_FMR_FINIT; // filter init mode on
		byte CAN2startPosition = (CAN1->FMR & CAN_FMR_CAN2SB) >> 8; // CAN2 filters start position

		for (byte i = (CANnum == 2) ? CAN2startPosition : 0; i < 28; ++i)
		{
			uint shift = 1 << i; // for choosing channel in settings regs
			if (CAN1->FA1R & shift) // filter is active
			{
				if (CANnum == 1 && (CAN1->FFA1R & shift)) // if CAN1 and filter assigned to FIFO1
				{
					byte nearest = 0;
					for (byte k = i + 1; k < 28; k++)
					{
						if ((CAN1->FFA1R & (1 << k)) == 0) // if filter assigned to FIFO1
						{
							nearest = k;
							break;
						}
					}
					if (nearest > 0)
					{
						moveFilter(i--, nearest);
						continue;
					}
					else
						break;
				}
				CANfilterScale regScale = ((CAN1->FS1R & shift) > 0) ? CANfilterScale::_29bit : CANfilterScale::_11bit;
				CANfilterMode regMode = ((CAN1->FM1R & shift) > 0) ? CANfilterMode::List : CANfilterMode::Mask;
				byte index = i / 8;
				byte shft = ((i % 8) * 4);
				if (scale == CANfilterScale::_11bit && regScale == CANfilterScale::_11bit)
				{
					if (mode == CANfilterMode::List && regMode == CANfilterMode::List)
					{
						if ((filterUtilization[index] & (2 << shft)) == 0) // we search for free quarter for 16bit filter mode. We need 1/4 reg
						{
							filterUtilization[index] |= 2 << shft;
							CAN1->sFilterRegister[i].FR1 = (id << (16 + 5)) | (CAN1->sFilterRegister[i].FR1 & 0xFFFF);
							noSpace = false;
						}
						else if ((filterUtilization[index] & (4 << shft)) == 0)
						{
							filterUtilization[index] |= 4 << shft;
							CAN1->sFilterRegister[i].FR2 = (id << (16 + 5)) | (id << 5);
							noSpace = false;
						}
						else if ((filterUtilization[index] & (8 << shft)) == 0)
						{
							filterUtilization[index] |= 8 << shft;
							CAN1->sFilterRegister[i].FR2 = (id << (16 + 5)) | (CAN1->sFilterRegister[i].FR2 & 0xFFFF);
							noSpace = false;
						}
						if (!noSpace)
							break;
					}
					else if (mode == CANfilterMode::Mask && regMode == CANfilterMode::Mask) // mode == mask
					{
						if ((filterUtilization[index] & (4 << shft)) == 0)
						{
							filterUtilization[index] |= 4 << shft; // we don't need to set q4 busy
							CAN1->sFilterRegister[i].FR2 = (msk << (16 + 5)) | (id << 5);
							noSpace = false;
							break;
						}
					}
				}
				else if (scale == CANfilterScale::_29bit && regScale == CANfilterScale::_29bit)
				{
					if (mode == CANfilterMode::List && regMode == CANfilterMode::List)
					{
						if ((filterUtilization[index] & (4 << shft)) == 0)
						{
							filterUtilization[index] |= 4 << shft; // we don't need to set q4 busy
							CAN1->sFilterRegister[i].FR2 = (_ID << 3) | 4;
							noSpace = false;
							break;
						}
					}
				}
			}
			else // filter is inactive
			{
				if (CANnum == 1)
				{
					if (i != CAN2startPosition)
						moveFilter(CAN2startPosition, i); // need to move filter
					CAN1->FMR = (CAN1->FMR & ~CAN_FMR_CAN2SB) | (++CAN2startPosition << 8); // CAN2 filters shift start position
				}
				filterUtilization[i / 8] |= 1 << ((i % 8) * 4); // we ready to take quater
				if (scale == CANfilterScale::_11bit)
				{
					if (mode == CANfilterMode::List)
					{
						CAN1->FM1R |= shift; // list mode
						CAN1->sFilterRegister[i].FR1 = (id << (16 + 5)) | (id << 5);
					}
					else // mode == mask
					{
						// we don't need to set q2 busy
						CAN1->sFilterRegister[i].FR1 = (msk << (16 + 5)) | (id << 5);
					}
					CAN1->sFilterRegister[i].FR2 = CAN1->sFilterRegister[i].FR1; // because FR2 will work on own id. It need to be same
				}
				else // scale == 29bit
				{
					CAN1->FS1R |= shift; // 29bit mode
					if (mode == CANfilterMode::List)
					{
						CAN1->FM1R |= shift; // list mode
						// we don't need to set q2 busy
						CAN1->sFilterRegister[i].FR1 = (_ID << 3) | 4;
						CAN1->sFilterRegister[i].FR2 = CAN1->sFilterRegister[i].FR1;                        // because FR2 will work on own id. It need to be same
					}
					else                        // mask mode
					{
						// we don't need to set q3 and q4 busy
						CAN1->sFilterRegister[i].FR1 = (_ID << 3) | 4;
						CAN1->sFilterRegister[i].FR2 = mask << 3;
					}
				}
				turnOn = i;                        // need to activate this register
				noSpace = false;
				break;
			}
		}
		if (!noSpace)
		{
			if (handler != nullptr)
			{
				uint32_t id_can = 0;
				bool is_exist = false;
				if (mode == CANfilterMode::List)
					id_can = _ID;
				else
					id_can = _ID & mask;
				if (CANnum == 2)
				{
					if (mode == CANfilterMode::List)
						callback2[idIndex2].id = _ID;
					else
						callback2[idIndex2].id = _ID & mask;
					callback2[idIndex2].mask = mask;
					callback2[idIndex2].mode = mode;
					callback2[idIndex2].scale = scale;
					if (typeid(handler) == typeid(Callback_data))
					{
						callback2[idIndex2].type_call = TypeCallback::_std;
					}
					else if (typeid(handler) == typeid(Callback_data_ext))
					{
						callback2[idIndex2].type_call = TypeCallback::_ext;
					}
					else
						callback2[idIndex2].type_call = TypeCallback::_none;
					callback2[idIndex2].handler = (void*) handler;
					callback2[idIndex2].is_active=true;
					idIndex2++;
				}
				else
				{
					for (uint32_t i = 0; i < idIndex1; i++)
					{
						if (callback1[i].id == id_can && callback1[i].mask == mask && callback1[i].mode == mode && callback1[i].scale == scale)
						{
							is_exist = true;
							break;
						}
					}
					if (!is_exist)
					{
						if (mode == CANfilterMode::List)
							callback1[idIndex1].id = _ID;
						else
							callback1[idIndex1].id = _ID & mask;
						callback1[idIndex1].mask = mask;
						callback1[idIndex1].mode = mode;
						callback1[idIndex1].scale = scale;
						if (typeid(handler) == typeid(Callback_data))
						{
							callback1[idIndex1].type_call = TypeCallback::_std;
						}
						else if (typeid(handler) == typeid(Callback_data_ext))
						{
							callback1[idIndex1].type_call = TypeCallback::_ext;
						}
						else
							callback1[idIndex1].type_call = TypeCallback::_none;
						callback1[idIndex1].handler = (void*) handler;
						callback1[idIndex1].is_active=true;
						idIndex1++;
					}
				}
			}
			if (turnOn >= 0)                        // need to activate filter and place to FIFO 1
			{
				if (CANnum == 2)
					CAN1->FFA1R |= 1 << turnOn;                        // filter assigned to FIFO 1
				CAN1->FA1R |= 1 << turnOn;                        // activate filter
			}
		}
		CAN1->FMR &= ~CAN_FMR_FINIT;                        // exit filter init mode
		return !noSpace;
	}
	bool controlCallback(byte CANnum, uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale, bool is_active);
	bool isRdy(CAN_TypeDef *s);
	bool isCnnct(CAN_TypeDef *s);
	bool isCnnctNode(CAN_TypeDef *s);
	void sendB(CAN_TypeDef *s, uint _ID, bool ext, byte data);
	bool sendP(CAN_TypeDef *s, uint _ID, bool ext, byte *data, byte dataLen);
	bool setSpd(CAN_TypeDef *can, CAN_SPEED speed);
	CAN_SPEED getSpd(CAN_TypeDef *can);
	bool deactivFilter(byte CANnum, uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);
};

class CAN1t final : public CANt
{
	static bool enabled;
	friend void CAN1_RX0_IRQHandler();
	static void processCAN1TX();
	static void processCAN1RX();
	static void translateCallback(uint32_t id, uint8_t* data, uint8_t size);
protected:
	CAN1t();
public:
	void enableTerminator();
	void disableTerminator();
	void sendByte(uint _ID, bool ext, byte data);
	bool isReady();
	bool isConnect();
	template<typename T>
	bool addFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale, T handler)
	{
		if (handler == nullptr)
			return addFilt(1, _ID, mask, mode, CANfilterScale::_29bit, nullptr);
		else
			return addFilt(1, _ID, mask, mode, scale, handler);
	}
	bool addFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale = CANfilterScale::_29bit);
	bool stopCallback(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);
	bool runCallback(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);

	void translate(uint32_t id, uint32_t mask, CANfilterMode mode, CANfilterScale scale = CANfilterScale::_29bit);

	static void enable();
	static void disable();
	bool setSpeed(CAN_SPEED speed);
	CAN_SPEED getSpeed();
	bool deactivateFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale)
	{
		return deactivFilter(1, _ID, mask, mode, scale);
	}
	static CAN1t &instance();
};

class CAN2t final : public CANt
{
	friend void CAN2_RX1_IRQHandler();
	static void processCAN2TX();
	static void processCAN2RX();
	static void translateCallback(uint32_t id, uint8_t* data, uint8_t size);
protected:
	CAN2t();
public:
	void enableTerminator();
	void disableTerminator();
	bool isReady();
	bool isConnect();
	bool addFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);
	template<typename T>
	bool addFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale, T handler)
	{
		return addFilt(2, _ID, mask, mode, scale, handler);
	}
	bool stopCallback(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);
	bool runCallback(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale);
	void translate(uint32_t id, uint32_t mask, CANfilterMode mode, CANfilterScale scale = CANfilterScale::_29bit);
	void sendByte(uint _ID, bool ext, byte data);
	bool setSpeed(CAN_SPEED speed);
	CAN_SPEED getSpeed();
	bool deactivateFilter(uint _ID, uint mask, CANfilterMode mode, CANfilterScale scale)
	{
		return deactivFilter(2, _ID, mask, mode, scale);
	}
	static CAN2t &instance();
};
}
