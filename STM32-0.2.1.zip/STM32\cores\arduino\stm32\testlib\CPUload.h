#include "Manager.h"
#include "Timer.h"

namespace System
{
	class CPUloadt : Manager, Timer
	{
		uint current;
		uint speed;
		void manager() override;
		virtual void tick_1Hz() override;
	public:
		CPUloadt();
		uint get();
	};// cpu load
}
