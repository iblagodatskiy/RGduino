#pragma once

#include "Types.h"
#include "RGprotocol.h"

enum class SystemCommands : byte
{
	Reset,
	Restarted,
	Online
};

enum class SystemParameters : byte
{
	CoreID// Read only
};

class Device : public RGprotocol
{
	bool onlineStatus = false;
	byte onlineStatusCnt = 0;

	virtual void systemSegmentPrepare() final;
	virtual void systemSegmentReceived(Segment<uint> *segment) final;
protected:
	virtual void tick_1Hz() override;
	Device(DeviceType type, byte group, bool listenMode) : RGprotocol(type, group, listenMode){};
public:
	bool isOnline();
};
