#pragma once

#include "Types.h"
#include "I2C.h"
#include "Config.h"

class Periphery;
struct BACKUP_PARAM
{
	byte key;
	ushort address;
	byte len;
};
namespace Hardware
{
	class EEPROMt : public I2Ct
	{
		friend class ::Periphery;
		EEPROMt();
		void writeEnable();
		void writeDisable();
		bool sendPack(ushort address, byte *data, ushort length);
		bool wByte(ushort address, byte data);
		bool wBuf(ushort address, byte *data, ushort length);
		bool writeBackupBuf(ushort address,byte *data, ushort length);
		bool restoreBackup();
	protected:
	public:
		bool writeSystemByte(byte address, byte data);
		bool writeSystemBuf(byte address, byte *data, ushort length);
		static EEPROMt &instance();
//		bool isBusy(uint timeout);
		bool writeByte(ushort address, byte data);
		bool readByte(ushort address, byte &data);
		bool writeBuf(ushort address, byte *data, ushort length);
		bool readBuf(ushort address, byte *data, ushort length);
		bool readSystemBuf(ushort address, byte *data, ushort length);
	};
}
