#include "Types.h"
#include "CAN.h"
#include "Peripheral.h"

#define ON true
#define OFF false

enum class DI {
	DI1 = 0,
	DI2,
	DI3,
	DI4,
	DI5,
	DI6,
	DI7,
	DI8,
	DI9,
	DI10,
	DI11,
	DI12,
	DI13,
	DI14,
	DI15,
	DI16,
	DI17,
	DI18,
	DI19,
	DI20,
	DI21,
	DI22,
	DI23,
	DI24
};

enum class LED {
	RED = 0,
	GREEN,
	BLUE
};

enum class DO {
	DO1 = 0,
	DO2,
	DO3,
	DO4,
	DO5,
	DO6,
	DO7,
	DO8,
	DO9,
	DO10,
	DO11,
	DO12,
	DO13,
	DO14,
	DO15,
	DO16
};

enum class PWM {
	PWM1 = 0,
	PWM2,
	PWM3,
	PWM4,
	PWM5,
	PWM6,
	PWM7,
	PWM8
};

enum class ACTIVATE {
	DISABLE = 0,
	ENABLE
};

/*enum class STATE:bool {
	OFF = 0,
	ON
};*/

enum class INPUT_TYPE {
	DISABLED = 0,
	DISCRETE_UP, // 0.5 from input voltage after divider
	DISCRETE_DOWN,
	VOLTAGE,
	CURRENT_LOOP,
	RESISTANCE,
	COUNTER,
	FREQUENCY,
	ALTERNATE_FUNCTION,
	FREQUENCY_ANALOG
};

enum class AMPLITUDE {
	HIGH = 0,
	MEDIUM,
	LOW,
	DIGIT,
	AMPLIFIED
};

enum class CAN_FILTER_MODE {
	MASK,
	LIST
};

enum class CAN_FILTER_SCALE {
	_11BIT,
	_29BIT
};

namespace RGduino
{
	void mainTask(void);
	
	class Can1_api {
	private:
	public:
		bool addFilter(uint ID_CAN, uint mask, CAN_FILTER_MODE mode, CAN_FILTER_SCALE scale, void (*link)(uint8_t*, uint8_t));
		void sendPack(uint ID_CAN, bool ext, byte *data, byte dataLen);
	};

	class Can2_api {
	private:
	public:
		bool addFilter(uint ID_CAN, uint mask, CAN_FILTER_MODE mode, CAN_FILTER_SCALE scale, void (*link)(uint8_t*, uint8_t));
		void sendPack(uint ID_CAN, bool ext, byte *data, byte dataLen);
	};
	
	
	
	namespace Digital
	{
		/*Настройки дискретных выходов:*/
		void pinMode(DO, ACTIVATE); //включение DO
		void pinMode(PWM, ACTIVATE); //включение PWM
		
		
		void digitalWrite(LED, bool); //управление встроенным светодиодом
		void digitalWrite(DO, bool); //управление дискретными выходами
		void digitalWrite(PWM, bool); //управление ШИМ как идскретным выходом
		
		int digitalRead(DI);
		
		
		void delay(int);
		void delayMicroseconds(int);
	} // End namespace Digital
	
	namespace Analog
	{
		void pinMode(DI, INPUT_TYPE);
		void pinMode(DI, INPUT_TYPE, AMPLITUDE);
		
		int analogRead(DI);
		
		void analogWrite(PWM, int);
	} // End namespace Analog
} // End namespace RGduino

