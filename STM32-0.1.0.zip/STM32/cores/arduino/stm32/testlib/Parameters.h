#pragma once

#include "Types.h"
#include "MyMath.h"
#include "Config.h"

template <typename T>
struct FlagVariable
{
public:
	bool newData = false;
	bool changed = false;
	T value;
}__attribute__ ((packed));

enum class ParameterType : byte// DONT CHANGE!
{
	Single,
	Double,
	Quad,
	fSingle,
	fDouble,
	fQuad,
	Array,
	fArray,

	Empty = (byte)-1
};

struct Parameter
{
	void *ptr;
	ushort id;
	ushort size;
	ParameterType type;
	enum class Status : byte
	{
		Suspense,
		TxPending,
		NeedToSend,
		Sent
	}status;
};

struct Command
{
	ushort id;
	void (*ptr)();
};

struct PendingCommands
{
	ushort id[COMMANDS_MAX_PENDING];
	byte cnt;
};

class ManualInstructions
{
	bool sendParam(void *ptr);
	bool parameterIsSnt(void *ptr);
protected:
	Parameter		parameter[PARAMETERS_MAX_NUMBER];
	byte			parametersCount;
	Command 		command[COMMANDS_MAX_NUMBER];
	byte			commandsCount;
	PendingCommands pendingCommands;

	ManualInstructions();
	bool getParameterIndex(ushort id, byte &index);
	bool addParam(ushort id, ParameterType type, void *ptr, ushort size);
	bool sendParamID(ushort id);
	void sendCom(ushort id);
public:
	template<typename T>
	bool addParameter(ushort id, T &ptr)
	{
		if (id >= 0x1C00) return false;
		ushort size = sizeof(T);
		if (size > PARAMETER_SIZE) return false;
		id += 0x400;
		ParameterType type;
		switch (size)
		{
			case 1: type = ParameterType::Single; break;
			case 2: type = ParameterType::Double; break;
			case 4: type = ParameterType::Quad; break;
			default: type = ParameterType::Array; break;
		}
		return addParam(id, type, (std::remove_volatile<T>*)&ptr, size);
	}

	template<typename T>
	bool addParameter(ushort id, T &ptr, ushort tsize) {
		if (id >= 0x1C00) return false;

		ushort size = sizeof(T);

		if (size > PARAMETER_SIZE)
			return false;

		if(tsize > size)
			return false;

		id += 0x400;
		ParameterType type;

		switch (tsize) {
			case 1: type = ParameterType::Single; break;
			case 2: type = ParameterType::Double; break;
			case 4: type = ParameterType::Quad; break;
			default: type = ParameterType::Array; break;
		}

		return addParam(id, type, (std::remove_volatile<T>*)&ptr, tsize);
	}

	template<typename T>
	bool addParameter(ushort id, FlagVariable<T> &ptr, ushort size = sizeof(T))
	{
		if (id >= 0x1C00) return false;
		if (size > PARAMETER_SIZE) return false;
		ParameterType type;
		switch (size)
		{
			case 1: type = ParameterType::fSingle; break;
			case 2: type = ParameterType::fDouble; break;
			case 4: type = ParameterType::fQuad; break;
			default: type = ParameterType::fArray; break;
		}
		id += 0x400;
		return addParam(id, type, &ptr, size);
	}

	template<typename T>
	bool addParameter(ushort id, T *ptr, ushort size)
	{
		if(id >= 0x1C00) return false;
		if (size > PARAMETER_SIZE) return false;
		id += 0x400;
		return addParam(id, ParameterType::Array, ptr, size);
	}

	template<typename T>
	bool sendParameter(T &ptr)
	{
		return sendParam(&ptr);
	}
	template<typename T>
	bool sendParameter(T *ptr)
	{
		return sendParam(ptr);
	}
	bool sendParameterID(ushort id);

	template<typename T>
	bool parameterIsReadyToSend(T &ptr)
	{
		return parameterIsSnt(&ptr);
	}
	template<typename T>
	bool parameterIsReadyToSend(T *ptr)
	{
		return parameterIsSnt(ptr);
	}

	byte getParametersCount() {
		return parametersCount;
	}

	bool getParameter(byte index, Parameter & param) {
		if (index < parametersCount)
		{
			param = parameter[index];
			return true;
		} else
			return false;
	}

	bool getParameter(ushort id, Parameter & param) {
		byte index;
		if (getParameterIndex(id, index))
		{
			param = parameter[index];
			return true;
		} else
			return false;
	}

	bool setParam(ushort id, byte data) {
		byte index;
		if (getParameterIndex(id, index))
			switch (parameter[index].type) {
			{
				case ParameterType::Single:
				*(byte*) parameter[index].ptr = data;
				return true;
			}
			{
				case ParameterType::fSingle:
				FlagVariable<byte> *pfv =
						(FlagVariable<byte>*) parameter[index].ptr;
				bool changed = pfv->value != data;
				pfv->value = data;
				pfv->changed = changed;
				pfv->newData = true;
				return true;
			}
			{
				default:
				return false;
			}
			}
		else
			return false;
	}

	bool setParam(ushort id, ushort data) {
		byte index;
		if (getParameterIndex(id, index))
			switch (parameter[index].type) {
			{
				case ParameterType::Double:
				*(ushort*) parameter[index].ptr = data;
				return true;
			}
			{
				case ParameterType::fDouble:
				FlagVariable<ushort> *pfv =
						(FlagVariable<ushort>*) parameter[index].ptr;
				bool changed = pfv->value != data;
				pfv->value = data;
				pfv->changed = changed;
				pfv->newData = true;
				return true;
			}
			{
				default:
				return false;
			}
			}
		else
			return false;
	}

	bool setParam(ushort id, uint data) {
		byte index;
		if (getParameterIndex(id, index))
			switch (parameter[index].type) {
			{
				case ParameterType::Quad:
				*(uint*) parameter[index].ptr = data;
				return true;
			}
			{
				case ParameterType::fQuad:
				FlagVariable<uint> *pfv =
						(FlagVariable<uint>*) parameter[index].ptr;
				bool changed = pfv->value != data;
				pfv->value = data;
				pfv->changed = changed;
				pfv->newData = true;
				return true;
			}
			{
				default:
				return false;
			}
			}
		else
			return false;
	}

	ParameterType getParamType(byte index) {
		if (index < parametersCount)
			return parameter[index].type;
		else
			return ParameterType::Empty;
	}

	bool addCommand(ushort id, void (*ptr)());
	bool sendCommand(ushort id);
};
