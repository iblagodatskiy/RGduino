#pragma once

#include "SerialPort.h"

namespace Hardware
{
	extern "C"
	{
		void USART1_IRQHandler();
	}

	class RS485_t : public SerialPort
	{
		friend void USART1_IRQHandler();
	protected:
		RS485_t();
	public:
		static RS485_t & instance();
		virtual uint getBitrate() override final;
		virtual void setBitrate(uint32_t bitrate) override final;
	};
}
