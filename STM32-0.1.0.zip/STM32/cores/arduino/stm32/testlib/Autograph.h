#pragma once

#include "Types.h"
#include "stdio.h"
#include "ModBus.h"

class Autograph
{
public:
	Autograph();
	void addParameter(ushort reg, bool isDword = false);
	void setTransmitPeriod(uint seconds);


private:
	uint8_t rxBuffer[32];
};
