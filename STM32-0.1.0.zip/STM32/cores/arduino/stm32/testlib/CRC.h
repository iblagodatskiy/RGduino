#pragma once

#include "Types.h"
#include "FreeRTOS.h"
#include "semphr.h"

namespace Hardware
{
	class CRCt final
	{
		CRCt();
		bool getBusy();
		void setBusy(bool val);
		xSemaphoreHandle xMutex;
		uint calcCRC(byte *buf, uint bufLen, bool reset);
	public:
		byte calcCRC8bit(byte *buf, uint bufLen);
		uint calculateBuf(byte *buf, uint bufLen, bool reset = true);
		uint get();
		void set(uint value);
		void next(uint data);
		void reset();
		static CRCt &instance();
	};
}
