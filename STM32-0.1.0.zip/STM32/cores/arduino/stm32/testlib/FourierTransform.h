#pragma once

#include "Types.h"
#include "arm_math.h"
#include "Config.h"

class FourierTransform
{
protected:
	bool active;
	uint periodFreq;//ticks with step 10uS
	bool newData;
	float result;

#if (FOURIER_ON==1)
	arm_cfft_radix4_instance_f32 S_CFFT;/* ARM CFFT module */
	arm_rfft_instance_f32 S;
#endif

	static void updateData();
public:
	enum class Type : byte
	{
		Disabled,
		Fourier,
		PeakDetect
	}type;

	enum State_peak
	{
		START = 0, RISING, FALLING
	};
	float *bufOuput;
#if (FOURIER_ON==1)
	float *bufOuput2;
#endif
	float *bufInput;
	float bufMediana[8];
	byte currPoint;
	uint length;
	bool waitCalc;
	bool start_calc;
	byte channel;
	float calculatePeak();
	float calculateFourier();
	FourierTransform(uint len, byte set_channel,Type type_input);
	~FourierTransform();
	float get();
	void set(byte pos_in_seq, byte num_channel, uint16_t * ptr_val, byte cnt_seq, uint32_t period_seq);
	bool getActive();
};

