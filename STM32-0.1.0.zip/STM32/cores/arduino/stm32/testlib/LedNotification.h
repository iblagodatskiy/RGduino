#pragma once
#include "Timer.h"
#include "SystemLeds.h"

enum class NotificationStatus
{
	ExternalFlashError
};

class LedNotification : protected System::Timer, public LedGroup
{
	virtual void tick_1Hz() override;
	virtual void tick_10Hz() override;
	uint errorList;
	uint errorCnt;
public:
	LedNotification();
	void addError(NotificationStatus error);
	void removeError(NotificationStatus error);
};
