#pragma once
#include "Types.h"

#define SHIFT_MASK(x)	((uint)1 << (x))
#define CLR_MASK(x)		(~SHIFT_MASK(x))

#define ShiftPin2(x) 	((x) * 2)
#define ShiftPin4(x)	((x) * 4)

#define MODERset(channel, type)	((uint32)(type) << ShiftPin2(channel))// Channel number 0-15, Type
#define MODERreset(channel)		(~(uint32)(3 << ShiftPin2(channel)))// Channel number 0-15
#define ModeOut		1
#define ModeAf		2
#define ModeAnalog	3

#define OTYPERset(channel)		((ushort)1 << (channel))// Channel number 0-15, 1: Output open-drain
#define OTYPERreset(channel)	(~OTYPERset(channel))// Channel number 0-15, 0: Output push-pull (reset state)

#define PUPDRset(channel, type) ((uint32)(type) << ShiftPin2(channel))// Channel number 0-15, Type
#define PUPDRreset(channel) 	(~(uint32)(3 << ShiftPin2(channel)))// Channel number 0-15
#define PupUP		1
#define PupDOWN		2

#define AFreg(GPIOx)				*((uint64 *)GPIOx->AFR)
#define AFset(channel, function)	((uint64)(function) << ShiftPin4(channel))// Channel number 0-15, Function number
#define AFreset(channel)			(~((uint64)0x0F << ShiftPin4(channel)))// Channel number 0-15

#define GPIOsetPin(port, pin)		(port->BSRR = 1 << ((pin) & 0x0F))
#define GPIOsetMask(port, mask)		(port->BSRR = (ushort)(mask))
#define GPIOresetPin(port, pin)		(port->BSRR = 1 << (((pin) & 0x0F) + 16))
#define GPIOresetMask(port, mask)	(port->BSRR = (uint)((mask) & 0xFFFF) << 16)

#define EXTI_ENABLE_SOFT_IT(__EXTI_LINE__)   	(EXTI->IMR1 |= (__EXTI_LINE__),EXTI->EMR1 |= (__EXTI_LINE__))
#define EXTI_GENERATE_SOFT_IT(__EXTI_LINE__)	(EXTI->SWIER1 |= (__EXTI_LINE__))
#define EXTI_ENABLE_IT(__EXTI_LINE__)   		(EXTI->IMR1 |= (__EXTI_LINE__))
#define EXTI_DISABLE_IT(__EXTI_LINE__)  		(EXTI->IMR1 &= ~(__EXTI_LINE__))
#define EXTI_CLEAR_IT(__EXTI_LINE__) 			(EXTI->PR1 |= (__EXTI_LINE__))

#define SET_BIT(REG, BIT)     ((REG) |= (BIT))
#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))
#define READ_BIT(REG, BIT)    ((REG) & (BIT))
#define CLEAR_REG(REG)        ((REG) = (0x0))
#define WRITE_REG(REG, VAL)   ((REG) = (VAL))
#define READ_REG(REG)         ((REG))
#define MODIFY_REG(REG, CLEARMASK, SETMASK)  WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))
#define POSITION_VAL(VAL)     (__CLZ(__RBIT(VAL)))
