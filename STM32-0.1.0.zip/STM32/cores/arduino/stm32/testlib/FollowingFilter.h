#pragma once
#include "DigitalFilter.h"

class FollowingFilter :	public DigitalFilter
{
	float diff;
public:
	FollowingFilter(uint len);
	virtual float get() final override;
	virtual float set(float val) final override;
};

