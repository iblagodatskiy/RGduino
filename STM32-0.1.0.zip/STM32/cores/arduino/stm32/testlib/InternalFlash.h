#pragma once

#include "CoreSettings.h"
#include "Types.h"

#define FLASH_KEY1		0x45670123
#define FLASH_KEY2		0xCDEF89AB
#define START_ADDR		0x08020000
#define FLASH_IS_BUSY	(FLASH->SR & FLASH_SR_BSY)

#define INTERNAL_FLASH_SECTOR_0		FLASH_BASE
#define INTERNAL_FLASH_SECTOR_1		(INTERNAL_FLASH_SECTOR_0 + 16_kb)
#define INTERNAL_FLASH_SECTOR_2		(INTERNAL_FLASH_SECTOR_1 + 16_kb)
#define INTERNAL_FLASH_SECTOR_3		(INTERNAL_FLASH_SECTOR_2 + 16_kb)
#define INTERNAL_FLASH_SECTOR_4		(INTERNAL_FLASH_SECTOR_3 + 16_kb)
#define INTERNAL_FLASH_SECTOR_5		(INTERNAL_FLASH_SECTOR_4 + 64_kb)
#define INTERNAL_FLASH_SECTOR_6		(INTERNAL_FLASH_SECTOR_5 + 128_kb)
#define INTERNAL_FLASH_SECTOR_7		(INTERNAL_FLASH_SECTOR_6 + 128_kb)
#define INTERNAL_FLASH_SECTOR_8		(INTERNAL_FLASH_SECTOR_7 + 128_kb)
#define INTERNAL_FLASH_SECTOR_9		(INTERNAL_FLASH_SECTOR_8 + 128_kb)
#define INTERNAL_FLASH_SECTOR_10	(INTERNAL_FLASH_SECTOR_9 + 128_kb)
#define INTERNAL_FLASH_SECTOR_11	(INTERNAL_FLASH_SECTOR_10 + 128_kb)

class InternalFlash
{
	InternalFlash() {};
public:
	static void lock();
	static void unlock();
	static void eraseSector(byte page);
	static void write(uint address, uint data);
	static void writeBuf(uint address, byte *data, uint size);
};
