#pragma once

#include <type_traits>

//---------- INTEGER TYPES ----------
typedef unsigned char uint8;
typedef unsigned char byte;
typedef signed char int8;
typedef signed char sbyte;

typedef unsigned short uint16;
typedef unsigned short ushort;
typedef signed short int int16;

typedef unsigned int uint;
typedef unsigned int uint32;

typedef unsigned long long uint64;
typedef signed long long int64;

constexpr unsigned long long operator ""_kb(unsigned long long bytes)
{
	return bytes * 1024;
}

constexpr unsigned long long operator ""_mb(unsigned long long bytes)
{
	return bytes * 1024 * 1024;
}

constexpr unsigned long long operator ""_gb(unsigned long long bytes)
{
	return bytes * 1024 * 1024 * 1024;
}

struct DateTime
{
	byte year;
	byte month;
	byte day;
	byte hour;
	byte minute;
	byte second;
	uint epoch;
};

union Value
{
	bool	BOOL;
	byte	BYTE;
	byte	DATA[4];
	short	SHORT;
	ushort	USHORT;
	int		INT;
	uint	UINT;
	float	FLOAT;
};

