
#ifndef SELFTEST_H_
#define SELFTEST_H_

#include "stdint.h"
//------------------------�����---------------------------------------
#define DISCRETE_OUTPUT_ALL_MASK		0xFFFF
#define PWM_OUTPUT_ALL_MASK				0xFF
#define PWM_FIRST_HALF_MASK				0xF
#define PWM_SECOND_HALF_MASK			0xF0
#define DISCRETE_OUTPUT_ODD_MASK		0xAAAA
#define DISCRETE_OUTPUT_EVEN_MASK		0x5555

#define HIGH_PWM_VALUE				1000
#define MEDIUM_PWM_VALUE			700
#define LOW_PWM_VALUE				310
#define PWM_OFF						0
//------------------------������--------------------------------------

#define ID_CAN_1						0x1FFF1259
#define ID_CAN_2						0x1FFF1269

//------------------------��������� ��������--------------------------

#define REFERENCE_CURRENT_IN				10000
#define REFERENCE_CURRENT_PWM				100

#define REFERENCE_VOLTAGE_HIGH_TOP			14000
#define REFERENCE_VOLTAGE_HIGH_BOT			6000

#define REFERENCE_VOLTAGE_MEDIUM_TOP		10000
#define REFERENCE_VOLTAGE_MEDIUM_BOT		4000

#define REFERENCE_VOLTAGE_LOW_TOP			2000
#define REFERENCE_VOLTAGE_LOW_BOT			1500

#define REFERENCE_RESISTANCE_ODD_TOP		200
#define REFERENCE_RESISTANCE_ODD_BOT		100

#define REFERENCE_RESISTANCE_EVEN_TOP		150
#define REFERENCE_RESISTANCE_EVEN_BOT		60

#define REFERENCE_RESISTANCE_MID_TOP		2500
#define REFERENCE_RESISTANCE_MID_BOT		1800

//#define REFERENCE_SUCCESS_PWM				400
//----------------------��������� ��������----------------------------
enum TEST_STAGE {
	TEST_CAN,
	TEST_PWM,
	TEST_VALTAGE,
	TEST_PULL,
	TEST_CURRENT,
	TEST_RESISTANSE
};
//----------------------��������� ������------------------------------
enum INPUT_STATE{
	STAGE_HIGH,
	STAGE_MEDIUM,
	STAGE_LOW,
	STAGE_PULL_UP,
	STAGE_PULL_DOWN,
	STAGE_CURRENT,
	STAGE_RESISTANSE
} ;
//------------------------����� ������---------------------------------
enum class ErrorFlag {
	START_TEST,
	NO_ERRORS,
	ERROR_CAN,
	ERROR_DO,
	ERROR_PWM,
	ERROR_DI_VOLTAGE,
	ERROR_DI_PULL,
	ERROR_DI_CURRENT,
	ERROR_DI_RESISTANCE,
	ERROR_EEPROM,
	ERROR_HSE,
	ERROR_LSE
};

ErrorFlag getSelfTestFlag();
uint32_t getSelfTestErrorChanel();
void setSelfTestStartFlag();





#endif /* SELFTEST_H_ */
