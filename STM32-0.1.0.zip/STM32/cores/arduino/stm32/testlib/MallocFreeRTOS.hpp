#pragma once

#include "FreeRTOS.h"
#include <stdlib.h>
uint16_t heapBITS_PER_BYTE=(( size_t ) 8 );

using namespace std;

typedef struct A_BLOCK_LINK
{
	struct A_BLOCK_LINK *pxNextFreeBlock; /*<< The next free block in the list. */
	size_t xBlockSize; /*<< The size of the free block. */
} BlockLink_t;

static const size_t xHeapStructSize	= ( sizeof( BlockLink_t ) + ( ( size_t ) ( portBYTE_ALIGNMENT - 1 ) ) ) & ~( ( size_t ) portBYTE_ALIGNMENT_MASK );

void checkDelete(void *p);

void * operator new(size_t n)
{
	return pvPortMalloc(n);
}
void operator delete(void * p)
{
	checkDelete(p);
}

void *operator new[](size_t n)
{
	return pvPortMalloc(n);
}

void operator delete[](void *p) throw ()
{
	checkDelete(p);
}
void checkDelete(void *p)
{
	uint8_t *puc = (uint8_t *) p;
	BlockLink_t *pxLink;
	size_t xBlockAllocatedBit = 0;
	xBlockAllocatedBit = ( ( size_t ) 1 ) << ( ( sizeof( size_t ) * heapBITS_PER_BYTE ) - 1 );
	if (p != NULL)
	{
		/* The memory being freed will have an BlockLink_t structure immediately
		 before it. */
		puc -= xHeapStructSize;

		/* This casting is to keep the compiler from issuing warnings. */
		pxLink = (BlockLink_t *) puc;

		/* Check the block is actually allocated. */
		if (((pxLink->xBlockSize & xBlockAllocatedBit) != 0) && (pxLink->pxNextFreeBlock == NULL))
		{
			vPortFree(p);
		}
		else
			free(p);
	}
}
