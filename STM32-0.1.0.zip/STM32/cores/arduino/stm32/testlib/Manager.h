#pragma once

#include "Types.h"
#include "MyMath.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "task.h"
#include "queue.h"
#include "Config.h"

namespace System
{
	class Manager
	{
		struct task {
				Manager * link_obj;
				void (*link_func)();
				TaskHandle_t handleTask;
				bool process;
				bool is_obj;
				task * new_addr;
				byte cnt_create;
				bool is_run;
				bool is_del;
			};
		static task buf_task[MANAGER_MAX_CNT];

		static byte cnt_task;

		virtual void manager() = 0;
		static bool enable(void (*link)(), bool process);
	protected:
		bool enable();
		bool disable();
	public:
		Manager(bool active = true) { if (active) enable(); };
		~Manager() { disable(); };
		static bool enable(void(*link)());
		static bool process(void(*link)());// Single activation and then disabling
		static bool disable(void(*link)());
		static void action();
		static void vTaskThread( void *pvParameters );
		static void vTaskProcess(void *pvParameter1, uint32_t ulParameter2);
	};
}

