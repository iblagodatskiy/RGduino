#pragma once
#include "RGprotocol.h"

class RGDevice : public Device
{
public:
	RGDevice(DeviceType type, byte group, bool listenMode) : Device(type, group, listenMode){};
};
