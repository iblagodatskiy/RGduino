#pragma once

#include "CoreSettings.h"
#include "SerialProtocol.h"

struct SerialSettings
{
	USART_TypeDef * module;
	GPIO_TypeDef * wePort;
	byte wePin;
};

class SerialPort
{
	void (*transmit)();
	void (*receive)(byte data);
	SerialSettings settings;
	ushort remain;
	byte * buf;
	bool protocolCallback;
	bool lastByte;
protected:
	void interrupt();
public:
	SerialPort(SerialSettings *set);
	void send(byte data);
	void send(char *str);
	void send(const char *str);
	void sendLine(char *str);
	void sendLine(const char *str);
	bool sendBuf(byte *data, ushort len);
	inline bool sendBuf(char *data, ushort len) {return sendBuf((byte *)data, len);};
	bool sendBufAsync(byte *data, ushort len);
	bool setCallback(void (*link)(byte data));
	bool setCallback(void (*link)());
	bool setCallback(SerialProtocol *prot);
	bool isBusy();
	void flush();
	virtual uint getBitrate() = 0;
	virtual void setBitrate(uint32_t bitrate)=0;
};
