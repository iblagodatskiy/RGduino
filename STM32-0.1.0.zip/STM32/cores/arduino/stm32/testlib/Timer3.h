#pragma once

#include <UCdevice.h>
#include "DoubleTimer.h"

extern "C"
{
	void TIM3_IRQHandler();
}

class Timer3 : public DoubleTimer
{
	friend class Periphery;
	friend void TIM3_IRQHandler();

	static Timer3 *module;

	Timer3(UCdevice &dev);
};
