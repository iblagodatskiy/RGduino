#pragma once

#include "CoreSettings.h"
#include "Types.h"

/*******************  Device electronic signature  ***************/
#define SIGNATURE_UID_BASE             0x1FFF7A10        /*!< Unique device ID register base address */
#define SIGNATURE_FLASHSIZE_BASE       0x1FFF7A22        /*!< FLASH Size register base address */

class DeviceSignature
{
	DeviceSignature() {};
public:
	static void getUID_12byte(uint8_t *buff);
	static uint32_t getUID_4byte();
	static uint32_t getFlash_size();
};
