#pragma once

#include "Types.h"
#include "CurrentMeasure.h"
#include "stdint.h"
#include "stm32f205xx.h"

#define ADC_V12_CHANNEL	2
#define ADC_VIN_CHANNEL	3
#define ADC_MULT_CHANNEL_GR_0	14
#define ADC_MULT_CHANNEL_GR_1	15
#define ADC_CURRENT_CHANNEL		13
#define ADC_DIRECT_CHANNEL_0	4
#define ADC_DIRECT_CHANNEL_1	5
#define ADC_DIRECT_CHANNEL_2	6
#define ADC_DIRECT_CHANNEL_3	7
#define ADC_DIRECT_CHANNEL_4	0
#define ADC_DIRECT_CHANNEL_5	1
#define ADC_DIRECT_CHANNEL_6	6
#define ADC_DIRECT_CHANNEL_7	7

#define ADC_FREQ_TRIGGER	100000 //HZ, 1 tick - 10uS

extern "C"
{
	void ADC_IRQHandler();
	void DMA2_Stream0_IRQHandler();
	void DMA2_Stream1_IRQHandler();
}

class Periphery;

class ADCt final : CurrentMeasure
{
	friend void ADC_IRQHandler();
	friend void DMA2_Stream0_IRQHandler();
	friend void DMA2_Stream1_IRQHandler();
	friend class Periphery;
	struct MultiGroupMeasure
	{
		uint *dataReg[3];
		byte channel;
		bool gr[2];
		byte currentChannel;
		bool currentMeas;
		bool firstMeas;
	}multiGroup;

	Periphery &device;
	bool fastMode[2];
	bool dma_ADC3_run;
	bool dma_ADC1_run;
	byte channel_pos_buff_ADC[8];
	byte cnt_ADC_inject[3];
	byte cnt_ADC_regular[3];
	uint16_t *ptr_buff_ADC1_0;
	uint16_t *ptr_buff_ADC1_1;
	uint16_t *ptr_buff_ADC3_0;
	uint16_t *ptr_buff_ADC3_1;
	bool start_InjectedADC3;
	bool start_InjectedADC2;
	bool start_InjectedADC1;
	bool init_ADC1_regular;
	bool init_ADC3_regular;
	float v12;
	void interrupt();
	static void interruptDMA(DMA_Stream_TypeDef * dma_stream, uint32_t period_seq);
	void calcInput(byte num, ushort reg);
	bool isReady();
	bool isFast(byte channel);
	void setInjected(byte channel, bool is_set=true);
	void setTrigger(ADC_TypeDef * adc, uint16_t samples);
	void setDMA(byte channel);
	bool getInjectChannel(ADC_TypeDef * adc, byte channel_adc, bool reset= false);
	bool getRegularChannel(ADC_TypeDef * adc, byte channel_adc, bool reset = false);
	void groupMeasure();
	void multiGroupMeasure();
	ADCt(Periphery &dev);
	void runRegularDMA(ADC_TypeDef * adc);
	void stopRegularDMA(ADC_TypeDef * adc);
	void runInjected(ADC_TypeDef * adc);
	void stopInjected(ADC_TypeDef * adc);
	byte getInjectCount(ADC_TypeDef * adc);
	byte getRegularCount(ADC_TypeDef * adc);
	byte addRegular(ADC_TypeDef * adc, byte channel_adc);
	byte addInject(ADC_TypeDef * adc, byte channel_adc);
	byte getPositionInject(ADC_TypeDef * adc, byte channel_adc);
	byte getPositionRegular(ADC_TypeDef * adc, byte channel_adc);
public:
	static ADCt *module;
	void calcInputFreqAnalog(byte num, float val);
	void autoPrescaler(byte num, float freq);
	void autoAdjust(byte num, uint16_t val);
};
