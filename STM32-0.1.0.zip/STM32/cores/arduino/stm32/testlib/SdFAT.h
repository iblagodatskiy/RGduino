#pragma once

#include "Types.h"
#include "stdio.h"

bool sdFatInit();
