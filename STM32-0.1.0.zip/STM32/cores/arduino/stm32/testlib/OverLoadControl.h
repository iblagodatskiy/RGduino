#pragma once

#include "Types.h"

class OverLoadControl
{
protected:
	static byte PWMs;
	static ushort DSs;
	static ushort DOs;
	static ushort cDisc;
	static ushort rDisc;
	static ushort value;
	static byte pMask;
	static byte dCounter[16];
	static byte pCounter[8];
	static void(*callback)(uint);
public:
	static bool setOverloadCallback(void(*call)(uint));
	static void resetOverloadCallback();
};