#pragma once
#include "SelfTest.h"
#include "ModBus.h"


class TestIO
{
	MBparameter *ModBusStateInputType[24];
	MBparameter *ModBusStateInputRange[24];
	MBparameter *ModBusStateInputValue[24];

#if(TEST_IO_EXTEND==1)
	MBparameter *ModBusStateInputLPF[24];
	MBparameter *ModBusStateInputFiltertype[24];
	MBparameter *ModBusStateInputFilterlength[24];
	MBparameter *ModBusStateInputupdateFastMode[24];
	MBparameter *ModBusStateInputHysteresDir[24];
	MBparameter *ModBusStateInputHysteresUpAnalog[24];
	MBparameter *ModBusStateInputHysteresDownAnalog[24];
	MBparameter *ModBusStateInputHysteresUpTiming[24];
	MBparameter *ModBusStateInputHysteresDownTiming[24];

	MBparameter *ModBusStateInputFouriertype[8];
	MBparameter *ModBusStateInputFourierLength[8];
#endif

	MBparameter *ModBusStateOut[16];
	MBparameter *ModBusStateOutAsInput[16];

	MBparameter *ModBusStatePWM[8];
	MBparameter *ModBusStatePWMValue[8];
	MBparameter *ModBusStatePWMCurrent[8];

	MBparameter *ModBusStateCAN[2];

	MBparameter *ModBusTestIO;

	MBparameter *ModBusLowClockSource;
	MBparameter *ModBusHighClockSource;

#if(TEST_IO_SELF_TEST==1)
	MBparameter *ModBusSelfTestFlag;
	MBparameter *ModBusSelfTestErrorChanel;
#endif

	bool is_init = false;
	TestIO()
	{
	}
	;
	friend void sendTestMODBUS();
public:
	static TestIO & instance();
	void init();
	void enable();
	void disable();
	void control();
};
void sendTestMODBUS();
#if(TEST_IO==1)
extern TestIO & testio;
#endif
