#pragma once
#include "CoreSettings.h"
#include "Config.h"
#include "TimeCallback.h"
#include "Parameters.h"
#include "math.h"
#include "ModBus.h"
typedef enum
{
	READ_REQ = 0x70, READ_ANSWER, WRITE_REQ, WRITE_ANSWER
} OPERATION;

#define DEFAULT_VAL_MIN		0
#define DEFAULT_VAL_MIDDLE	0
#define DEFAULT_VAL_MAX		46
#define DEFAULT_VAL_FLOW	8
#define DEFAULT_VAL_TURTLE	96
/***************************
 * ��������� ��������
 ***************************/
struct JOY_CONFIG_ZERO_POINT
{
	union
	{
		uint8_t y_offset[8];
		uint64_t data;
	};
	JOY_CONFIG_ZERO_POINT()
	{
		data=DEFAULT_VAL_MIN;
	};
}__attribute__ ((packed));

struct JOY_CONFIG_BEZIER
{
	union
	{
		uint8_t data[6];
		struct
		{
			uint8_t x_0;
			uint8_t y_0;
			uint8_t x_1;
			uint8_t y_1;
			uint8_t coefFlow;
			uint8_t turtle;
		};
	};
	JOY_CONFIG_BEZIER()
	{
		x_0 = 0;
		y_0 = DEFAULT_VAL_MIDDLE;
		x_1 = 100;
		y_1 = DEFAULT_VAL_MAX;
		coefFlow = DEFAULT_VAL_FLOW;
		turtle = DEFAULT_VAL_TURTLE;
	}
}__attribute__ ((packed));

struct USER_CONFIG_BEZIER
{
	uint8_t min;
	uint8_t middle;
	uint8_t max;
	uint8_t flow;
	uint8_t turtle;
}__attribute__ ((packed));

/*******************************
 * ������ ��������
 *******************************/
struct PACKET_BEZIER
{
	OPERATION command :8;
	JOY_CONFIG_BEZIER config;
}__attribute__ ((packed));
struct PACKET_ZERO_POINT
{
	OPERATION command :8;
	JOY_CONFIG_ZERO_POINT config;
}__attribute__ ((packed));
struct PACKET_NUM_BEZIER
{
	OPERATION command :8;
	uint8_t count=0;
}__attribute__ ((packed));
/********************************
 * ������� �� ����
 ********************************/
struct FLASH_BEZIER
{
	JOY_CONFIG_BEZIER data;
	uint8_t crc;
}__attribute__ ((packed));

struct FLASH_ZERO_POINT
{
	JOY_CONFIG_ZERO_POINT data;
	uint8_t crc;
}__attribute__ ((packed));

struct MODBAS_BEZIER_CONFIG
{
	MBparameter *low;
	uint8_t *write_low;
	MBparameter *middle;
	uint8_t *write_middle;
	MBparameter *max;
	uint8_t *write_max;
	MBparameter *flow;
	uint8_t *write_flow;
	MBparameter *turtle;
	uint8_t *write_turtle;
}__attribute__ ((packed));


class JoyBezier
{
	friend class PWMt;
private:
	void checkJoyConfig();
	friend void checkJoyConfigModbas();
protected:
#if(BEZIER_COUNT<=8)
	FlagVariable<PACKET_BEZIER> joys_rx_conf_0[BEZIER_COUNT];
	JOY_CONFIG_BEZIER joys_config_0[BEZIER_COUNT];
	ushort old_val_0[BEZIER_COUNT];
#else
	FlagVariable<PACKET_BEZIER> joys_rx_conf_0[8];
	JOY_CONFIG_BEZIER joys_config_0[8];
	ushort old_val_0[8];
#if(BEZIER_COUNT<=16)
	FlagVariable<PACKET_BEZIER> joys_rx_conf_1[BEZIER_COUNT-8];
	JOY_CONFIG_BEZIER joys_config_1[BEZIER_COUNT-8];
	ushort old_val_1[BEZIER_COUNT-8];
	FlagVariable<PACKET_ZERO_POINT> zero_point_rx_1;
	JOY_CONFIG_ZERO_POINT zero_point_1;
#endif
#endif
	FlagVariable<PACKET_ZERO_POINT> zero_point_rx_0;
	JOY_CONFIG_ZERO_POINT zero_point_0;
	uint16_t enabled_mask_Bezier;
	uint8_t count_Bezier;
	FlagVariable<PACKET_NUM_BEZIER> num_curves;

	//Modbas params
	/*
	 * ��������� �� ������/������
	 */
	MODBAS_BEZIER_CONFIG modbas_params[BEZIER_COUNT];
	MBparameter ModBusBezierControl=MBparameter(0x03, 1201, 1);
	uint16_t soft_stop_mask=0;

public:
	JoyBezier(uint8_t cnt=BEZIER_COUNT):count_Bezier(cnt)
	{
		for(uint8_t i=0;i<count_Bezier;i++)
		enabled_mask_Bezier|=1<<i;
	}
	bool enableMaskSoftStop(uint16_t mask);
	bool enableSoftStop(uint8_t num);
	bool disableSoftStop(uint8_t num);
	bool enableMaskBezier(uint16_t mask);
	bool enable();
	bool readConfig(uint8_t num);
	bool readConfigZero(uint8_t num);
	uint8_t getConfigZero(uint8_t num);
	bool writeConfig(uint8_t num);
	bool writeConfigZero(uint8_t num);
	int16_t getBezierValue(uint8_t num, uint16_t joy_val, bool is_turtle=false);
	void control();
	float getTurtleCoef(uint8_t num);
	bool setTurtleCoef(byte chan,byte _turtle);
	bool rewriteDefaultConfig(USER_CONFIG_BEZIER config, uint8_t num);/*���������� �������� ��-���������*/
};
void checkJoyConfigModbas();
