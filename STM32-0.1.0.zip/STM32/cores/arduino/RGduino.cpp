
#include "Arduino.h"

using namespace System;
RGduino::Can1_api Can1;
RGduino::Can2_api Can2;
namespace RGduino
{
	bool RGduino::Can1_api::addFilter(uint ID_CAN, uint mask, CAN_FILTER_MODE mode, CAN_FILTER_SCALE scale, void (*link)(uint8_t*, uint8_t)) {
		return periphery.Can1.addFilter(ID_CAN, mask, (Hardware::CANfilterMode)mode, (Hardware::CANfilterScale)scale, link);
	}

	void RGduino::Can1_api::sendPack(uint ID_CAN, bool ext, byte *data, byte dataLen) {
		periphery.Can1.sendPack(ID_CAN, ext, data, dataLen);
	}

	bool RGduino::Can2_api::addFilter(uint ID_CAN, uint mask, CAN_FILTER_MODE mode, CAN_FILTER_SCALE scale, void (*link)(uint8_t*, uint8_t)) {
		return periphery.Can2.addFilter(ID_CAN, mask, (Hardware::CANfilterMode)mode, (Hardware::CANfilterScale)scale, link);
	}

	void RGduino::Can2_api::sendPack(uint ID_CAN, bool ext, byte *data, byte dataLen) {
		periphery.Can2.sendPack(ID_CAN, ext, data, dataLen);
	}
	

	void mainTask(void)
	{
		HostBootStat updateState = periphery.getUpdateStage();
		if(updateState == HostBootStat::Disabled)
		{
			loop();
		}
	}

	
	namespace Digital
	{
		//LED ledBuiltin;
		
		void digitalWrite(LED ledColor, bool state){
			switch(ledColor){
				case LED::RED:
					if ((bool)state)
						periphery.led.red.on();
					else
						periphery.led.red.off();
					break;
				case LED::GREEN:
					if ((bool)state)
						periphery.led.green.on();
					else
						periphery.led.green.off();
					break;
				case LED::BLUE:
					if ((bool)state)
						periphery.led.blue.on();
					else
						periphery.led.blue.off();
					break;
				default:
					break;
			}
		}
		
		void pinMode(DO channel, ACTIVATE condition){
			if ((bool)condition)
				periphery.discreteOutputs.enable((byte)channel);
			else
				periphery.discreteOutputs.disable((byte)channel);
		}
		
		void pinMode(PWM channel, ACTIVATE condition) {
			if ((bool)condition) {
				periphery.PWM.enable((byte)channel, true);
				//periphery.PWM.enableCurrentMeasure((byte)channel);
			} else
				periphery.PWM.disable((byte)channel);
		}
		
		void digitalWrite(DO channel, bool state){
			periphery.discreteOutputs.set((byte)channel, (bool)state);
			periphery.discreteOutputs.update();
		}
		
		void digitalWrite(PWM channel, bool state){
			if ((bool)state)
				periphery.PWM.set((byte)channel, 1000);
			else 
				periphery.PWM.set((byte)channel, 0);
		}
		
		int digitalRead(DI channel) {
			return (int)(periphery.input[(byte)channel].value.Discrete);
		}
		
		void delay(int delay) {
			System::Timer::Delay_ms(delay);
		}
		void delayMicroseconds(int us) {
			System::Timer::Delay_us(us);
		}

	} // End namespace Digital

	namespace Analog
	{
		InputChannelSettings discreteObject[25];

		void pinMode(DI channel, INPUT_TYPE typeInput) {
			switch(typeInput) {
				case INPUT_TYPE::DISCRETE_UP:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::DiscreteUp;
					break;
				case INPUT_TYPE::DISCRETE_DOWN:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::DiscreteDown;
					break;
				case INPUT_TYPE::VOLTAGE:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Voltage;
					#warning "Amplitude not specified! Used by default - AMPLITUDE_HIGH"
					break;
				case INPUT_TYPE::CURRENT_LOOP:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::CurrentLoop;
					break;
				case INPUT_TYPE::RESISTANCE:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Resistance;
					#warning "Amplitude not specified! Used by default - AMPLITUDE_HIGH"
					break;
				case INPUT_TYPE::COUNTER:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Counter;
					break;
				case INPUT_TYPE::FREQUENCY:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Frequency;
					break;
				case INPUT_TYPE::ALTERNATE_FUNCTION:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::AlternateFunction;
					break;
				case INPUT_TYPE::FREQUENCY_ANALOG:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::FrequencyAnalog;
					break;
				default:
					break;
			}
			discreteObject[(byte)channel].update = 5;
			periphery.inputChannelEnable((byte)channel, discreteObject[(byte)channel]);
		}
		
		void pinMode(DI channel, INPUT_TYPE typeInput, AMPLITUDE amplitude) {
			switch(typeInput) {
				case INPUT_TYPE::DISCRETE_UP:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::DiscreteUp;
					break;
				case INPUT_TYPE::DISCRETE_DOWN:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::DiscreteDown;
					break;
				case INPUT_TYPE::VOLTAGE:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Voltage;
					break;
				case INPUT_TYPE::CURRENT_LOOP:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::CurrentLoop;
					break;
				case INPUT_TYPE::RESISTANCE:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Resistance;
					break;
				case INPUT_TYPE::COUNTER:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Counter;
					break;
				case INPUT_TYPE::FREQUENCY:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::Frequency;
					break;
				case INPUT_TYPE::ALTERNATE_FUNCTION:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::AlternateFunction;
					break;
				case INPUT_TYPE::FREQUENCY_ANALOG:
					discreteObject[(byte)channel].type = InputChannelSettings::Type::FrequencyAnalog;
					break;
				default:
					break;
			}
			
			switch(amplitude) {
				case AMPLITUDE::HIGH:
					discreteObject[(byte)channel].amplitude = InputChannelSettings::Amplitude::High;
					break;
				case AMPLITUDE::MEDIUM:
					discreteObject[(byte)channel].amplitude = InputChannelSettings::Amplitude::Medium;
					break;
				case AMPLITUDE::LOW:
					discreteObject[(byte)channel].amplitude = InputChannelSettings::Amplitude::Low;
					break;
				case AMPLITUDE::DIGIT:
					discreteObject[(byte)channel].amplitude = InputChannelSettings::Amplitude::Digit;
					break;
				case AMPLITUDE::AMPLIFIED:
					discreteObject[(byte)channel].amplitude = InputChannelSettings::Amplitude::Amplified;
					break;
				default:
					break;
			}
			discreteObject[(byte)channel].update = 5;
			periphery.inputChannelEnable((byte)channel, discreteObject[(byte)channel]);
		}

		int analogRead(DI channel) {
			uint32_t valueTmp = 0;
			switch(periphery.input[(byte)channel].getSettings()->type) {
				
				case InputChannelSettings::Type::Voltage:
					valueTmp = (uint32_t) (periphery.input[(byte)channel].value.Voltage * 1000 + 0.5);
					break;
				case InputChannelSettings::Type::Resistance:
					valueTmp = (uint32_t) periphery.input[(byte)channel].value.Resistance;
					break;
				case InputChannelSettings::Type::CurrentLoop:
					valueTmp = (uint32_t) (periphery.input[(byte)channel].value.CurrentLoop * 1000000 + 0.5);//in micro amper
					break;
				case InputChannelSettings::Type::Counter:
					valueTmp = (uint32_t) periphery.input[(byte)channel].value.Counter;
					break;
				case InputChannelSettings::Type::Frequency:
					valueTmp = (uint32_t) (periphery.input[(byte)channel].value.Frequency);
				default:
					break;
			}
			return valueTmp;
		}
		
		void analogWrite(PWM channel, int duty) {
			periphery.PWM.set((byte)channel, duty);
		}
	} // End namespace Analog
} // End namespace RGduino





