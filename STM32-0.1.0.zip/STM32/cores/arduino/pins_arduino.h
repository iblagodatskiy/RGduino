/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

const LED LED_BUILTIN_RED = LED::RED;
const LED LED_BUILTIN_GREEN = LED::GREEN;
const LED LED_BUILTIN_BLUE = LED::BLUE;


const PWM PWM_1 = PWM::PWM1;
const PWM PWM_2 = PWM::PWM2;
const PWM PWM_3 = PWM::PWM3;
const PWM PWM_4 = PWM::PWM4;
const PWM PWM_5 = PWM::PWM5;
const PWM PWM_6 = PWM::PWM6;
const PWM PWM_7 = PWM::PWM7;
const PWM PWM_8 = PWM::PWM8;

const DO DO_1 = DO::DO1; // Мб заменить номера каналов на наименование со жгута?
const DO DO_2 = DO::DO2;
const DO DO_3 = DO::DO3;
const DO DO_4 = DO::DO4;
const DO DO_5 = DO::DO5;
const DO DO_6 = DO::DO6;
const DO DO_7 = DO::DO7;
const DO DO_8 = DO::DO8;
const DO DO_9 = DO::DO9;
const DO DO_10 = DO::DO10;
const DO DO_11 = DO::DO11;
const DO DO_12 = DO::DO12;
const DO DO_13 = DO::DO13;
const DO DO_14 = DO::DO14;
const DO DO_15 = DO::DO15;
const DO DO_16 = DO::DO16;

const DI DI_1 = DI::DI1;
const DI DI_2 = DI::DI2;
const DI DI_3 = DI::DI3;
const DI DI_4 = DI::DI4;
const DI DI_5 = DI::DI5;
const DI DI_6 = DI::DI6;
const DI DI_7 = DI::DI7;
const DI DI_8 = DI::DI8;
const DI DI_9 = DI::DI9;
const DI DI_10 = DI::DI10;
const DI DI_11 = DI::DI11;
const DI DI_12 = DI::DI12;
const DI DI_13 = DI::DI13;
const DI DI_14 = DI::DI14;
const DI DI_15 = DI::DI15;
const DI DI_16 = DI::DI16;
const DI DI_17 = DI::DI17;
const DI DI_18 = DI::DI18;
const DI DI_19 = DI::DI19;
const DI DI_20 = DI::DI20;
const DI DI_21 = DI::DI21;
const DI DI_22 = DI::DI22;
const DI DI_23 = DI::DI23;
const DI DI_24 = DI::DI24;
	
const INPUT_TYPE DISCRETE_UP = INPUT_TYPE::DISCRETE_UP;
const INPUT_TYPE DISCRETE_DOWN = INPUT_TYPE::DISCRETE_DOWN;
const INPUT_TYPE VOLTAGE = INPUT_TYPE::VOLTAGE;
const INPUT_TYPE CURRENT_LOOP = INPUT_TYPE::CURRENT_LOOP;
const INPUT_TYPE RESISTANCE = INPUT_TYPE::RESISTANCE;
const INPUT_TYPE COUNTER = INPUT_TYPE::COUNTER;
const INPUT_TYPE FREQUENCY = INPUT_TYPE::FREQUENCY;
const INPUT_TYPE ALTERNATE_FUNCTION = INPUT_TYPE::ALTERNATE_FUNCTION;
const INPUT_TYPE FREQUENCY_ANALOG = INPUT_TYPE::FREQUENCY_ANALOG;

const AMPLITUDE AMPLITUDE_HIGH = AMPLITUDE::HIGH;
const AMPLITUDE AMPLITUDE_MEDIUM = AMPLITUDE::MEDIUM;
const AMPLITUDE AMPLITUDE_LOW = AMPLITUDE::LOW;
const AMPLITUDE AMPLITUDE_DIGIT = AMPLITUDE::DIGIT;
const AMPLITUDE AMPLITUDE_AMPLIFIED = AMPLITUDE::AMPLIFIED;

const ACTIVATE DISABLE = ACTIVATE::DISABLE;
const ACTIVATE ENABLE = ACTIVATE::ENABLE;

const CAN_FILTER_MODE MASK = CAN_FILTER_MODE::MASK;
const CAN_FILTER_MODE LIST = CAN_FILTER_MODE::LIST;
const CAN_FILTER_SCALE _29BIT = CAN_FILTER_SCALE::_29BIT;
const CAN_FILTER_SCALE _11BIT = CAN_FILTER_SCALE::_11BIT;


//const STATE OFF = STATE::OFF;
//const STATE ON = STATE::ON;
/*
 * Pin number mask
 * allows to retrieve the pin number without ALTx
 */
