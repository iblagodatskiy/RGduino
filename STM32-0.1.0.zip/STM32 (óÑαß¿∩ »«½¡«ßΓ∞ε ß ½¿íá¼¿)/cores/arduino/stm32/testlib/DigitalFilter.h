#pragma once

#include "Types.h"

class DigitalFilter
{
protected:
	bool active;
	float *buf;
	uint length;
	uint counter;
	uint fill;
	float result;
public:
	DigitalFilter(float *ptr, uint len);
	~DigitalFilter();
	virtual float get() = 0;
	virtual float set(float val) = 0;
	bool getActive();
};

#include "AverageFilter.h"
#include "FollowingFilter.h"
#include "ThresholdFilter.h"
