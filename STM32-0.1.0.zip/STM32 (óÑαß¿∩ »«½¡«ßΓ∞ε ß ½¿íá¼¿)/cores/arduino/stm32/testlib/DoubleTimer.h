#pragma once

#include "Timer.h"
#include "CoreSettings.h"
#include "InputChannel.h"

class DoubleTimer : protected System::Timer
{
	friend class Periphery;

	InputChannel &channel_1;
	InputChannel &channel_2;
	bool modeFreqEn[2];
	bool sync[2];
	bool prescalerUpdate;
	bool decreasePossible;
	bool decreaseRequired[2];
	bool measureOngoing[2];
	int mDif[2];
	byte active;
	byte overflow[2];
	uint counter[2];
	byte divider[2];
	ushort tune[2];
protected:
	TIM_TypeDef *timer;

	void interrupt();
	void measure(byte index);
	void stop(byte index);
	void enable(byte index);
	void disable(byte index);
	void increaseDivider(byte index);
	void decreaseDivider(byte index);
	void increasePsc(byte index);
	void decreasePsc();
	virtual void tick_10Hz();//10Hz
	DoubleTimer(TIM_TypeDef *tim, void (*init_clock)(), InputChannel &chan1, InputChannel &chan2);
};
