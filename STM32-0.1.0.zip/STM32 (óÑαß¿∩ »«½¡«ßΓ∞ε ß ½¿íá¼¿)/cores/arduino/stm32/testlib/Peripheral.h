#pragma once
#include "Factory.h"
#include "UCdevice.h"
#include "Timer3.h"
#include "EEPROM.h"
#include "Flash.h"
#include "CPUload.h"
#include "ADC.h"
#include "Timer10.h"
#include "Timer11.h"
#include "Timer13.h"
#include "Timer14.h"
#include "Timer5.h"
#include "Flash.h"
#include "LedNotification.h"
#include "RS232.h"
#include "RS485.h"
#include "PWMt.h"
#include "DiscreteOutputs.h"
#include "Config.h"
#include "InputControl.h"
#include "SDIO.h"
#if( VOLTAGE_CONTROL==1)
	#include "VoltageControl.h"
#endif
#include "CAN.h"
#include "Wdog.h"
#include "RTC.h"

enum class StateModule: byte
{
	STATE_OFF=0,
	STATE_ON,
	STATE_ERR
};

class Periphery final : public UCdevice
{
	static uint inputRangeUpdate;
	Timer10 Tim10	= *this;
	Timer11 Tim11	= *this;
	Timer13 Tim13	= *this;
	Timer14 Tim14	= *this;
	Timer3	Tim3	= *this;
	Timer5	Tim5	= *this;
	InputControl inputControl;
	static uint temp;
	static uint remain;
	static byte bootRepeatCounter;
	static HostBootStat hostBootStat;
	typedef struct
	{
		UCcommandsID commWait;
		UCcommandsID commSend;
		bool is_wait;
	} WaitComm;

	Periphery();
	virtual void tick_1Hz() override;
	virtual void tick_100Hz() override;
	virtual void bootHandler(UCparametersID idParam) override;
	virtual void bootUpdate() override;
	static void bootManager();
	static void bootFlashInit();
	static void clearAllMemory();

	static void rangeAdjustActivation();
	void inputChannelSet(byte channel, InputChannelSettings &setting);
	void inputChannelReset(byte channel);
	
	void deviceSegmentPrepare();

	static void	digitalFilterHandler();
	static void fourierHandler();
	static void sendUpdateStatus();

public:
	static struct StateModuleStruct
	{
		StateModule ADCmodule;
		StateModule Ledmodule;
		StateModule PWMmodule;
		StateModule DOmodule;
		StateModule RS232module;
		StateModule RS485module;
		StateModule Eeprommodule;
		StateModule	SDIOmodule;
		StateModule Can1module;
		StateModule Can2module;
		StateModule Flashmodule;
		StateModule Crcmodule;
		StateModule WatchDogmodule;
		StateModule Rtcmodule;
	}stateModules;

	ADCt ADCunit;
	WaitComm wait;
	void inputChannelClearCounter(byte channel);
	void inputChannelSetCounterState(byte channel, bool enabled);
#if (SIMPLE_LED ==1)
	LedGroup led;
#else
	LedNotification led;
#endif // SIMPLE_LED
	bool saveGroup;
	PWMt PWM;
	DiscreteOutputs discreteOutputs;
#if (VOLTAGE_CONTROL ==1)
	VoltageControl voltageControlModule;
#endif // VOLTAGE_CONTROL
	Hardware::RS232_t &RS232 = Factory::get<RS232_t>();
	Hardware::RS485_t &RS485 = Factory::get<RS485_t>();
	Hardware::EEPROMt &eeprom = Factory::get<EEPROMt>();
#if (SD_CARD == 1)
	Hardware::SDIOt &SDcard= Factory::get<SDIOt>();
#endif // SD_CARD
	Hardware::CAN1t &Can1=Factory::get<CAN1t>();
#if(UC22_CAN2==1)
	Hardware::CAN2t &Can2=Factory::get<CAN2t>();
#endif
	FlashT &flash=Factory::get<FlashT>();
	Hardware::CRCt &crc = Factory::get<CRCt>();
#if (WATCHDOG == 1)
	WDt &watchDog = Factory::get<WDt>();
#endif // WATCHDOG_USE
#if (RTC_TIME==1)
	RTCt &rtc = Factory::get<RTCt>();
#endif // RTC_HSE
#if (BEZIER_COUNT != 0)
	JoyBezier Bezier= JoyBezier();
#endif // SD_CARD

#if (CPU_LOAD==1)
	CPUloadt CPUload;
#endif // CPU_LOAD

	static Periphery & instance();
	float getBusVoltage();
	HostBootStat getUpdateStage();
};
extern Periphery & periphery;
