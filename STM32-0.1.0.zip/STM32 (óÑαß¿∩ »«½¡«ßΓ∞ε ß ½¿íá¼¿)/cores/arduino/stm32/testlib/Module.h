#pragma once
#include "CANContainer.h"
class Param
{
private:
protected:
public:
	uint32_t size = 0;
	uint8_t req_buff[8];
	virtual uint8_t *getReadReq()
	{
		req_buff[0] = OPERATION_READ_REQ;
		req_buff[1] = (uint8_t) getNumParam();
		memcpy(&req_buff[2], getPtrParam(), size);
		return &req_buff[0];
	}
	virtual uint8_t *getWriteReq()
	{
		req_buff[0] = OPERATION_WRITE_REQ;
		req_buff[1] = (uint8_t) getNumParam();
		memcpy(&req_buff[2], getPtrParam(), size);
		return &req_buff[0];
	}
	virtual NUM_PARAM getNumParam()
	{
		return NUM_PARAM_NONE;
	}
	;
	virtual uint8_t *getPtrParam()
	{
		return nullptr;
	}
	;
	Param(uint32_t _size)
	{
		size = _size;
	}
};

class Module
{
private:

	class Angle: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_ANGLE param;
		Angle() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_ANGLE();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_ANGLE_SENSOR;
		}
		virtual uint8_t *getPtrParam()
		{
			return (uint8_t*) &param;
		}
	};

	class CANp: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_CAN param;
		CANp() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_CAN();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_CAN;
		}
		virtual uint8_t *getPtrParam()
		{
			return (uint8_t*) &param;
		}
	};

	class Radio: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_RADIO param;
		Radio() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_RADIO();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_RADIO;
		}
		virtual uint8_t *getPtrParam()
		{
			return (uint8_t*) &param;
		}
	};
	class Rssi: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_RSSI param;
		Rssi() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_RSSI();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_RSSI;
		}
		virtual uint8_t *getPtrParam()
		{
			return (uint8_t*) &param;
		}
	};

	class Stab_pid: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_PID_STAB param;
		NUM_PARAM num_axis=NUM_PARAM_STAB_PID_YAW;
		Stab_pid(NUM_PARAM _num_axis) : num_axis(_num_axis),
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_PID_STAB();
		}
		virtual NUM_PARAM getNumParam()
		{
			return num_axis;
		}
	};
	class Stab_out: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_STAB_OUT param;
		Stab_out() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_STAB_OUT();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_STAB_PID_OUT;
		}
	};

	class Filter: public Param
	{
		friend class Param;
	private:
	protected:
	public:
		PARAM_CAN_FILTER param;
		Filter() :
				Param(sizeof(param))
		{
		}
		void reset()
		{
			param = PARAM_CAN_FILTER();
		}
		virtual NUM_PARAM getNumParam()
		{
			return NUM_PARAM_CAN_FILTER;
		}
		virtual uint8_t *getPtrParam()
		{
			return (uint8_t*) &param;
		}
	};
protected:

public:
	Angle angle;
	CANp can;
	Radio radio;
	Rssi rssi;
	Stab_pid stab_yaw=Stab_pid(NUM_PARAM_STAB_PID_YAW);
	Stab_pid stab_pitch=Stab_pid(NUM_PARAM_STAB_PID_PITCH);
	Stab_pid stab_roll=Stab_pid(NUM_PARAM_STAB_PID_PITCH);
	Stab_out stab_out;
	Filter filter;

	uint32_t base_id = 0;
	uint32_t data_id_radio = 0;
	uint32_t data_id_angle = 0;

	Module(uint32_t _base_id = CAN_BASE_RADIO_CONFIG, uint32_t _data_id_radio = CAN_BASE_RADIO_DATA, uint32_t _data_id_angle = CAN_BASE_ANGLE_SENSOR_DEF) :
			base_id(_base_id), data_id_radio(_data_id_radio), data_id_angle(_data_id_angle)
	{

	}

	void setConfig(uint8_t * buff)
	{
		//buff[0] - code operation
		if(buff[0]!=OPERATION_READ_ANSWER && buff[0]!=OPERATION_WRITE_ANSWER)
			return;
		switch (buff[1])
		{
		case NUM_PARAM_ANGLE_SENSOR:
			angle.param=*(PARAM_ANGLE*)&buff[2];
			break;
		case NUM_PARAM_CAN:
			can.param= *(PARAM_CAN*)&buff[2];
			break;
		case NUM_PARAM_RADIO:
			if((*(PARAM_RADIO*)&buff[2]).id_can==0 || (*(PARAM_RADIO*)&buff[2]).mode>comm_NONE || (*(PARAM_RADIO*)&buff[2]).mode<comm_SEARCH)
				break;
			radio.param=*(PARAM_RADIO*)&buff[2];
			break;
		case NUM_PARAM_RSSI:
			rssi.param=*(PARAM_RSSI*)&buff[2];
			break;
		case NUM_PARAM_CAN_FILTER:
			filter.param=*(PARAM_CAN_FILTER*)&buff[2];
			break;
		default:
			break;
		}
	}
	template<typename T>
	T * getConfig(NUM_PARAM num_param)
	{
		switch (num_param)
		{
		case NUM_PARAM_ANGLE_SENSOR:
			return angle.param;
		case NUM_PARAM_CAN:
			return angle.param;
		case NUM_PARAM_RADIO:
			return radio.param;
		case NUM_PARAM_RSSI:
			return rssi.param;
		case NUM_PARAM_CAN_FILTER:
			return filter.param;
		default:
			return nullptr;
		}
	}

};
