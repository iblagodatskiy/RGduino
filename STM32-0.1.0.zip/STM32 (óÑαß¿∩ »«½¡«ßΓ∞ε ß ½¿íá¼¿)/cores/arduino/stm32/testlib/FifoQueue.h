#pragma once

#include "Types.h"
#include "Config.h"

//FIFO for different sized elements

class FifoQueue
{
protected:
	typedef struct{
		uint16_t ptrHead;
		uint16_t size;
	} Element;
	Element *ptrElements;
	byte* queue;
	uint16_t size;
	uint16_t lastPush;
	uint16_t cnt;
	volatile bool is_write;
	volatile bool is_read;

public:

	FifoQueue(uint16_t len, byte minSize=2);
	~FifoQueue();
	bool push(byte * data, uint16_t size_buff);
	bool pull(byte * buff, uint16_t buff_size,uint16_t cntElem=1);
	uint32_t getCount();
};

