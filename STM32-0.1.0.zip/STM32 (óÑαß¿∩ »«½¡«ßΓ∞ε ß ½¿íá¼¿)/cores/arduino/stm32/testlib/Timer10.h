#pragma once

#include "UCdevice.h"
#include "SingleTimer.h"

extern "C"
{
	void TIM1_UP_TIM10_IRQHandler();
}

class Timer10 : public SingleTimer
{
	friend class Periphery;
	friend void TIM1_UP_TIM10_IRQHandler();

	static Timer10 *module;

	Timer10(UCdevice &dev);
};
