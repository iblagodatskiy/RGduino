/*! \mainpage Short description of RG UC library usage.

\section intro_sec Introduction

This is the introduction.

\section install_sec Installation

\subsection step1 Step 1: Opening the box

etc...
*/