﻿#ifndef FAULT_IT_HPP
#define FAULT_IT_HPP

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void vApplicationStackOverflowHook(xTaskHandle xTask, signed portCHAR* pcTaskName);
void vApplicationMallocFailedHook();
void vApplicationIdleHook(void);
void _write_check_code(void);
uint32_t _check_stack_size(void);

#ifdef __cplusplus
}
#endif

#endif // FAULT_IT_HPP

