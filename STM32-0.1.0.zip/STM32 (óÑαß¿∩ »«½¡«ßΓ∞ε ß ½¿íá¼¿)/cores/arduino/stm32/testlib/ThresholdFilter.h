#pragma once
#include "DigitalFilter.h"

class ThresholdFilter :	public DigitalFilter
{
	float *buf;
	ushort length;
	byte counter;
	byte amount;
	float result;
	float threshold;
	float difference;
	float cSum;
public:
	ThresholdFilter(ushort len);
	~ThresholdFilter();
	virtual float get() final override;
	virtual float set(float val) final override;
};

