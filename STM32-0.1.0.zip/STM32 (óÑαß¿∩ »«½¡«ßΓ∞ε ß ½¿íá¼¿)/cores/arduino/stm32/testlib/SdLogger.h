#pragma once

#include "nmea.h"

void printLog(const char* str, bool sync = true);
void loggerInit();

TimeTypedef& getTimeBuffer();
DateTypedef& getDateBuffer();
