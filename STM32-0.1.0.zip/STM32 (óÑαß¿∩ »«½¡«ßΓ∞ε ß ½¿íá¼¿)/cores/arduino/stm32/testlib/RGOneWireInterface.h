#pragma once

#include "RGOneWire.h"

class RGOneWireHardware
{
public:
	RGOneWireHardware(byte a);
};

