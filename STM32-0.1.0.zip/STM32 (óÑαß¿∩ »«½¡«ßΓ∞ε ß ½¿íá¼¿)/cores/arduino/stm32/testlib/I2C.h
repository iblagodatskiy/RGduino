#pragma once

#include "Types.h"

#define SCL_PIN 8
#define SDA_PIN 9

extern "C"
{
	void I2C1_EV_IRQHandler();
	void I2C1_ER_IRQHandler();
}

class I2Ct
{
protected:
	I2Ct();
};
