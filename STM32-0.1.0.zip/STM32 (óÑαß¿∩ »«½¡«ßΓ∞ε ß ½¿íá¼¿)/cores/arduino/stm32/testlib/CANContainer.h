#pragma once

#include "ProtocolContainer.h"
#include "CAN.h"

#define ADR_CONFIG_DEFAULT_ENABLE_3AX			1
#define ADR_CONFIG_DEFAULT_INVERSE_Y			0
#define ADR_CONFIG_DEFAULT_ENABLE_Y_VEL_STAB	0
#define ADR_CONFIG_DEFAULT_ENABLE_Y_STAB		0

#define CAN_BASE_RADIO_CONFIG					0x18FF2021
#define CAN_BASE_ANGLE_SENSOR_DEF				0x18FF2024
#define CAN_BASE_RADIO_DATA						0x18FF2025
#define CAN_INPUTEXTENDER_ID_0					0x18FF2A20
#define CAN_INPUTEXTENDER_ID_1					0x18FF2A21

typedef struct __attribute__ ((packed))
{
	uint32_t	ID;
	bool		IDE;
	uint8_t		DLC;
	uint8_t		data[8];
} MESSAGE_CAN;

typedef enum
{
	OPERATION_READ_REQ=0x70,
	OPERATION_READ_ANSWER,
	OPERATION_WRITE_REQ,
	OPERATION_WRITE_ANSWER
}CODE_OPERATION;

typedef enum
{
	NUM_PARAM_ANGLE_SENSOR=1,
	NUM_PARAM_CAN,
	NUM_PARAM_RADIO,
	NUM_PARAM_RSSI,

	NUM_PARAM_STAB_PID_YAW,
	NUM_PARAM_STAB_PID_PITCH,
	NUM_PARAM_STAB_PID_ROLL,
	NUM_PARAM_STAB_PID_OUT,
	NUM_PARAM_STAB_VELOCITY,
	NUM_PARAM_CAN_FILTER,
	NUM_PARAM_CONTROL,
	NUM_PARAM_CORRECTION,
	NUM_PARAM_NONE
}NUM_PARAM;

typedef enum
{
	RADIO_SEARCH=0,
	RADIO_BIND,		//linking connection
	RADIO_PING,		//initial connection
	RADIO_DATA		//data communication
}STATE_RADIO;

typedef enum
{
	MESSAGE_ID_KEY=0,
	MESSAGE_ID_JOY_0_3,
	MESSAGE_ID_JOY_4_7,
	MESSAGE_ID_LED_FEEDBACK,
	MESSAGE_ID_MASK_LED,
	MESSAGE_ID_STATUS,
	MESSAGE_ID_STRING,
	MESSAGE_ID_LED_FEEDBACK_EXT,
	MESSAGE_ID_MASK_LED_EXT,
}RADIO_MESSAGE_ID;

typedef enum
{
	MESSAGE_FROM_CLIENT=0,
	MESSAGE_FROM_PULT,
}RADIO_MESSAGE_DIRECTION;

struct PARAM_ANGLE
{
	bool enable_3_axsis:1;
	bool inverse_y_axsis:1;
	bool enable_velocity_stab:1;
	bool enable_stab:1;
	bool enable:1;
	bool is_ext_id:1;
	bool is_radio_transfer:1;
	bool calibrate:1;
	uint8_t period;
	uint32_t id_can;
	PARAM_ANGLE()
	{
		enable_3_axsis=true;
		inverse_y_axsis=false;
		enable_velocity_stab=false;
		enable_stab=false;
		enable=false;
		is_ext_id=true;
		is_radio_transfer=false;
		calibrate=false;
		period=20;
		id_can=CAN_BASE_ANGLE_SENSOR_DEF;
	}
}__attribute__ ((packed));

struct CAN_COIL {
	uint8_t limit;
	uint8_t	id: 4;
	uint8_t	dead_zone: 3;
	bool selected: 1;
}__attribute__ ((packed));
typedef struct  __attribute__ ((packed)) {
	int16_t P;
	int16_t I;
	int16_t D;
} PID_STAB_Pack;
struct PARAM_PID_STAB {
	PID_STAB_Pack stab_pid;
	PARAM_PID_STAB() {
		stab_pid.P =
				stab_pid.I =
						stab_pid.D = 0;
	}
} __attribute__ ((packed));

struct PARAM_VEL_STAB {
	int16_t yaw_vel;
	int16_t pitch_vel;
	int16_t roll_vel;
	PARAM_VEL_STAB() {
		yaw_vel =
				pitch_vel =
						roll_vel = 100;
	}
} __attribute__ ((packed));

struct PARAM_CORRECTION {
	uint8_t head_in_source;
	uint8_t head_out_source;
	uint8_t position_in_source;
	uint8_t position_out_source;
	uint16_t empty;
	PARAM_CORRECTION() {
		empty = -1;
		head_in_source =
				head_out_source =
						position_in_source =
							position_out_source = 0xff;
	}
} __attribute__ ((packed));

typedef union __attribute__ ((packed)) {
	int16_t analog_limit[3];
	CAN_COIL can[3];
} STAB_OUT_Pack;
struct PARAM_STAB_OUT {
	STAB_OUT_Pack stab_out;
	PARAM_STAB_OUT() {
			stab_out.analog_limit[0] = 1000;
			stab_out.analog_limit[1] = 1000;
			stab_out.analog_limit[2] = 1000;
		}
} __attribute__ ((packed));
typedef enum:uint8_t
{
	TYPE_MASK=0b0,
	TYPE_ID=0b1,
}TYPE_SOURCE_ID;

typedef enum:uint8_t
{
	MODE_MASK=0b0,
	MODE_LIST=0b1,
}MODE_FILTER;

typedef enum:uint8_t
{
	SCALE_11bit=0b0,
	SCALE_29bit=0b1,
}SCALE_FILTER;

struct PARAM_CAN_FILTER
{
	uint8_t num_bank:8;
	bool is_active:1;//0 - inactive, 1 - active
	SCALE_FILTER scale:1; //0 - standart, 1 - extended
	MODE_FILTER mode:1;//0 - mode mask, 1 - mode list
	TYPE_SOURCE_ID type_source:1;//0 - current id is mask, 1 - current id is ID
	bool read_all:1;//0 - read from num_bank, 1 - read all configuration filters
	uint8_t :3;
	uint32_t id;
	uint32_t mask;
	PARAM_CAN_FILTER()
	{
		num_bank=0;
		is_active=true;
		scale=SCALE_29bit;
		mode=MODE_MASK;
		type_source=TYPE_ID;
		id=CAN_INPUTEXTENDER_ID_0;
		mask=CAN_INPUTEXTENDER_ID_0;
	}
} __attribute__ ((packed));

struct PARAM_CAN
{
	CAN_SPEED speed:8;
	bool enable:1;
	bool terminator:1;
	uint8_t :3;
	bool is_ext_id:1;
	bool restart:1;
	bool to_update:1;
	uint32_t id_can;
	PARAM_CAN()
	{
		speed=SPEED_250kb;
		enable=true;
		terminator=false;
		is_ext_id=true;
		restart=false;
		to_update=false;
		id_can=CAN_BASE_RADIO_CONFIG;
	}
} __attribute__ ((packed));

struct PARAM_RADIO
{
	Communicate_mode mode:3;
	Type_tranciever type:1;
	bool enable:1;
	bool is_ext_id:1;
	bool state_search:1;
	bool state_link:1;
	uint8_t period;
	uint32_t id_can;
	PARAM_RADIO()	{
		mode=Communicate_mode::comm_SEARCH;
		type=Type_tranciever::SLAVE;
		enable=true;
		is_ext_id=true;
		state_search=false;
		state_link=false;
		period=10;
		id_can=CAN_BASE_RADIO_DATA;
	}
} __attribute__ ((packed));

struct PARAM_RSSI
{
	uint8_t rssi;
	PARAM_RSSI()	{
		rssi=0;
	}
} __attribute__ ((packed));

struct PARAM_CONTROL
{
	bool reset_to_default:1;
	bool clear_calibrate:1;
	uint8_t :5;
	bool to_update:1;
	uint32_t:32;
	uint8_t key_code;
	PARAM_CONTROL()	{
		key_code=0x86;
	}
} __attribute__ ((packed));

struct MESSAGE_ANGLE_EULER
{
	int16_t angle_z;
	int16_t angle_y;
	int16_t angle_x;

	uint8_t :6;
	uint8_t correction_not_end:1;
	uint8_t err_orient:1;
}__attribute__ ((packed));

struct MESSAGE_ANGLE_Y
{
	float angle_y;
	uint8_t mark;
}__attribute__ ((packed));
struct MESSAGE_ANGLE_QUAT16
{
	int16_t x;
	int16_t y;
	int16_t z;
	int16_t w;
}__attribute__ ((packed));

struct MESSAGE_RADIO_HEAD
{
	RADIO_MESSAGE_ID id_packet:7;
	RADIO_MESSAGE_DIRECTION direction:1;
}__attribute__ ((packed));

struct MESSAGE_RADIO_FEEDBACKS
{
	uint8_t data[4];
	void setValue(uint8_t index, bool value)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return;
		data[index/8] &=~(1<<(index%8));
		data[index/8] |=value<<(index%8);
	}
	bool getValue(uint8_t index)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return false;
		else
			return (bool)((data[index/8]>>(index%8)) & 0b1);
	}
}__attribute__ ((packed));

struct MESSAGE_RADIO_FEEDBACKS_EXT
{
	uint8_t data[5];
	void setValue(uint8_t index, bool value)
	{
		if(index>=PROTOCOL_COUNT_LED_EXT)
			return;
		data[index/8] &=~(1<<(index%8));
		data[index/8] |=value<<(index%8);
	}
	bool getValue(uint8_t index)
	{
		if(index>=PROTOCOL_COUNT_LED_EXT)
			return false;
		else
			return (bool)((data[index/8]>>(index%8)) & 0b1);
	}
}__attribute__ ((packed));

struct MESSAGE_RADIO_STATUS
{
	uint8_t data[6];
	void setBuzzer(bool value)
	{
		data[0] = value;
	}
	bool getBuzzer()
	{
		return (bool) data[0];
	}
	void setRSSI(uint8_t value)
	{
		data[1] = value;
	}
	uint8_t getRSSI()
	{
		return data[1];
	}
	void setRSSILed(uint8_t value)
	{
		data[2] = value;
	}
	uint8_t getRSSILed()
	{
		return data[2];
	}
	void setVoltage(uint8_t value)
	{
		data[3] = value;
	}
	uint8_t getVoltage()
	{
		return data[3];
	}
	void setVoltageLed(uint8_t value)
	{
		data[4] = value;
	}
	uint8_t getVoltageLed()
	{
		return data[4];
	}
	void setBlock(bool value)
	{
		data[5] = value;
	}
	bool getBlock()
	{
		return data[5];
	}
};
struct MESSAGE_RADIO_LEDMASK
{
	uint8_t data[4];
	void setValue(uint32_t value)
	{
		*(uint32_t*)(&data[0])=value;
	}
	void setValue(uint8_t index, bool value)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return;
		data[index/8] &=~(1<<(index%8));
		data[index/8] |=value<<(index%8);
	}
	uint32_t getValue()
	{
		return *(uint32_t*)(&data[0]);
	}
	bool getValue(uint8_t index)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return false;
		else
			return (bool)((data[index/8]>>(index%8)) & 0b1);
	}
}__attribute__ ((packed));

struct MESSAGE_RADIO_LEDMASK_EXT
{
	uint8_t data[5];
	void setValue(uint64_t value)
	{
		*(uint32_t*)(&data[0])=value;
		data[5]=(value>>32) & 0xFF;
	}
	void setValue(uint8_t index, bool value)
	{
		if(index>=PROTOCOL_COUNT_LED_EXT)
			return;
		data[index/8] &=~(1<<(index%8));
		data[index/8] |=value<<(index%8);
	}
	uint64_t getValue()
	{
		uint64_t tmp=0;
		*(uint32_t*)(&tmp)=*(uint32_t*)(&data[0]);
		tmp |=data[5];
		return tmp;
	}
	bool getValue(uint8_t index)
	{
		if(index>=PROTOCOL_COUNT_LED_EXT)
			return false;
		else
			return (bool)((data[index/8]>>(index%8)) & 0b1);
	}
}__attribute__ ((packed));

struct MESSAGE_RADIO_KEYS
{
	uint8_t data[4];
	void setValueKey(uint8_t index, bool value)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return;
		data[index/8] &=~(1<<(index%8));
		data[index/8] |=value<<(index%8);
	}
	bool getValueKey(uint8_t index)
	{
		if(index>=PROTOCOL_COUNT_KEY)
			return false;
		else
			return (bool)((data[index/8]>>(index%8)) & 0b1);
	}
}__attribute__ ((packed));

struct MESSAGE_RADIO_JOYS
{
	uint8_t data[6];
	void setValueJoy(uint8_t index, float value, bool _is_calibrate)
	{
		if(index>=PROTOCOL_COUNT_JOY/2)
			return;
		if(value>1000)
			value=1000;
		else if(value<-1000)
			value=-1000;
		uint16_t val=(uint16_t)(value<0)?(value/(-1)):value;
		bool is_negative=(value<0)?true:false;
		bool is_calibrate=_is_calibrate;
		val |=is_negative<<10;
		val |=is_calibrate<<11;
		data[((index*12)/8)] &=(uint8_t)(~(0xFFF<<((index%2)?4:0)));
		data[(((index*12)/8)+1)] &=(uint8_t)(~(0xFFF>>((index%2)?4:8)));
		data[((index*12)/8)]|=(uint8_t)(val<<((index%2)?4:0)) ;//������� �����
		data[(((index*12)/8)+1)]|=(uint8_t)(val>>((index%2)?4:8));//������� �����
	}
	float getValueJoy(uint8_t index, bool &is_calibrate)
	{
		if(index>=PROTOCOL_COUNT_JOY/2)
			return 0;
		float value=0;
		uint16_t val=0;
		val = (data[((index*12)/8)] & (0xFFF<<((index%2)?4:0)))>>((index%2)?4:0);//������� �����
		val |=(data[(((index*12)/8)+1)] & (0xFFF>>((index%2)?4:8)))<<((index%2)?4:8);//������� �����
		bool is_negative=(((val>>10)>>0) & 0b1)?true:false;
		is_calibrate =((val>>11)>0)?true:false;
		val &=~(0b11<<10);
		value=(is_negative)?val*(-1):val;
		return value;
	}
}__attribute__ ((packed));
struct MESSAGE_RADIO_STRING
{
	uint8_t start_byte=0;
	char string[6];
}__attribute__ ((packed));

struct MESSAGE_FEEDBACK
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_FEEDBACKS data;
	MESSAGE_FEEDBACK()
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_LED_FEEDBACK;
	}
}__attribute__ ((packed));

struct MESSAGE_FEEDBACK_EXT
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_FEEDBACKS_EXT data;
	MESSAGE_FEEDBACK_EXT()
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_LED_FEEDBACK_EXT;
	}
}__attribute__ ((packed));

struct MESSAGE_STATUS
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_STATUS data;
	MESSAGE_STATUS()
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_STATUS;
	}
}__attribute__ ((packed));

struct MESSAGE_LEDMASK
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_LEDMASK data;
	MESSAGE_LEDMASK()
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_MASK_LED;
	}
}__attribute__ ((packed));

struct MESSAGE_LEDMASK_EXT
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_LEDMASK_EXT data;
	MESSAGE_LEDMASK_EXT()
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_MASK_LED_EXT;
	}
}__attribute__ ((packed));

struct MESSAGE_KEY
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_KEYS data;
	MESSAGE_KEY()
	{
		head.direction=MESSAGE_FROM_PULT;
		head.id_packet=MESSAGE_ID_KEY;
	}
}__attribute__ ((packed));

struct MESSAGE_JOY
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_JOYS data;
	MESSAGE_JOY(uint8_t num_group=0)
	{
		head.direction=MESSAGE_FROM_PULT;
		if(!num_group)
			head.id_packet=MESSAGE_ID_JOY_0_3;
		else
			head.id_packet=MESSAGE_ID_JOY_4_7;
	}
}__attribute__ ((packed));

struct MESSAGE_STRING
{
	MESSAGE_RADIO_HEAD head;
	MESSAGE_RADIO_STRING data;
	MESSAGE_STRING(uint8_t num_group=0)
	{
		head.direction=MESSAGE_FROM_CLIENT;
		head.id_packet=MESSAGE_ID_STRING;
	}
}__attribute__ ((packed));

struct MESSAGE_INPUTEXT_JOY
{
	int16_t axis_0;
	int16_t axis_1;
	bool key_0;
	bool key_1;
	bool key_2;
	bool key_3;
};
