#!/bin/bash

COMPILER_PATH="$1"
BUILD_PATH="$2"
BUILD_PROJECT_NAME="$3"
TOOL_PATH="$4"

"$COMPILER_PATH/arm-none-eabi-objcopy" -O binary "$BUILD_PATH/$BUILD_PROJECT_NAME.elf" "$BUILD_PATH/$BUILD_PROJECT_NAME.bin"
"$TOOL_PATH/RGfirmwareBootUtility.exe" "$BUILD_PATH/$BUILD_PROJECT_NAME.bin"
if [ -f "$BUILD_PATH/rezult.bin" ]; then
  rm "$BUILD_PATH/rezult.bin"
fi
cat "$TOOL_PATH/uc_boot.bin" "$BUILD_PATH/$BUILD_PROJECT_NAME.bin" >> "$BUILD_PATH/rezult.bin"