#pragma once

#include "Types.h"
#include "Timer.h"
#include "Manager.h"

class RGOneWire : System::Timer, System::Manager
{
	enum class Status
	{
		Synchronization,
		Synchronized,
		Transmit,
		Receive
	};

	enum class Phase
	{
		Sync,
		Command,
		Length,
		Data,
		Crc,
		ACK
	};

	enum class Control
	{
		NoCommand,
		Set,
		Reset
	};

	Status status;
	Phase phase;
	Control control;

	byte channel;
	ushort counter;
	byte buffer[8];
	byte *link;
	byte length;
	ushort crc;
	byte crcTemp;
	bool level;
	bool checkCrc;

	virtual void tick_1000Hz() override;
	virtual void manager() override;

	bool send(byte *buf, byte len);
	void receive(byte *buf, byte len);
	void selectDirection(byte val, byte bit);
	void set();
	void reset();

public:
	enum class Result
	{
		OK,
		Pending,
		TransmitFail,
		ReceiveFail
	};

	Result result;

	RGOneWire(byte chan);
};
