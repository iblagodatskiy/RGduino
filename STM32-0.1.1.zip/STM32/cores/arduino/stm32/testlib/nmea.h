#pragma once

#include <string>
#include <cstdlib>
#include "stm32f2xx.h"
#include "GPIOLib.h"


enum GpsState
{
  Off    = 0,
  Search,
  Found
};

typedef struct
{
	unsigned char hour, minute, second;
}TimeTypedef;

typedef struct
{
	unsigned char day, month, year;
}DateTypedef;

extern "C"
{
	void USART2_IRQHandler();
}
class NMEA
{
public:

	void manager();

	TimeTypedef getTime();
	uint getIntTime();
	unsigned char getHour();
	unsigned char getMinute();
	unsigned char getSecond();
	float getLatitude();
	float getLongitude();
	float getSpeed();
	float getDirection();
	DateTypedef getDate();
	uint16_t getDistance();
	uint32_t getUnixDateTime();
	uint getIntDate();
	GpsState getStatus();
	unsigned char getDay();
	unsigned char getMonth();
	unsigned char getYear();
	void setTimezone(signed char timezone);
	signed char getTimezone();
	static NMEA & instance(signed char t=0);
	void reset();
private:
	NMEA()
	{
		NMEA(0);
	}
	NMEA(signed char t)
	{
		Timezone = t;
		status = Off;
	}
	unsigned char nmeaTempStr[11];
	TimeTypedef time;
	float latitude, longitude;
	DateTypedef date;
	GpsState status;
	signed char Timezone;
	float speed;
	float direction;
};
class nmeaRMC
{
public:
	nmeaRMC();
	nmeaRMC(signed char t);
	~nmeaRMC();

	void manager();

	TimeTypedef getTime(){
		return NMEA::instance().getTime();
	};
	uint getIntTime()
	{
		return NMEA::instance().getIntTime();
	}
	unsigned char getHour()
	{
		return NMEA::instance().getHour();
	}
	unsigned char getMinute()
	{
		return NMEA::instance().getMinute();
	}
	unsigned char getSecond()
	{
		return NMEA::instance().getSecond();
	}
	float getLatitude()
	{
		return NMEA::instance().getLatitude();
	}
	float getLongitude()
	{
		return NMEA::instance().getLongitude();
	}
	float getSpeed()
	{
		return NMEA::instance().getSpeed();
	}
	float getDirection()
	{
		return NMEA::instance().getDirection();
	}
	DateTypedef getDate()
	{
		return NMEA::instance().getDate();
	}
	uint16_t getDistance()
	{
		return NMEA::instance().getDistance();
	}
	uint32_t getUnixDateTime()
	{
		return NMEA::instance().getUnixDateTime();
	}
	uint getIntDate()
	{
		return NMEA::instance().getIntDate();
	}
	GpsState getStatus()
	{
		return NMEA::instance().getStatus();
	}
	unsigned char getDay()
	{
		return NMEA::instance().getDay();
	}
	unsigned char getMonth()
	{
		return NMEA::instance().getMonth();
	}
	unsigned char getYear()
	{
		return NMEA::instance().getYear();
	}
	void setTimezone(signed char timezone)
	{
		return NMEA::instance().setTimezone(timezone);
	}
	signed char getTimezone()
	{
		return NMEA::instance().getTimezone();
	}
};

void NMEA_Handler(byte data);
