#pragma once
#include "DigitalFilter.h"

class AverageFilter : public DigitalFilter
{
public:
	AverageFilter(uint len);
	~AverageFilter() {};
	virtual float get() final override;
	virtual float set(float val) final override;
};

