#ifndef _BUILD_TYPE_H_
#define _BUILD_TYPE_H_

typedef enum {

	//Using for marking version that is in development
	BUILD_TYPE_DEV =	0U,

	//Using for marking version that is in beta stage
	BUILD_TYPE_BETA =	1U,

	//Using for marking version that is in stable stage
	BUILD_TYPE_STABLE =	2U

} BUILD_TYPE;

#endif
