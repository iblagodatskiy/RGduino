#pragma once

#include "Types.h"

class SerialProtocol
{
public:
	virtual void rxHandler(byte data) = 0;
	virtual void txHandler() = 0;
};