#pragma once

#include "stdint.h"

#define MMC_BLOCK_SIZE	512

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

	uint32_t mmcGetSectorCount();
	uint8_t mmcGetStatus();
	uint8_t mmcReadBlock(uint8_t* buf, uint32_t sector, uint32_t blocksNum);
	uint8_t mmcWriteBlock(uint8_t* buf, uint32_t sector, uint32_t blocksNum);
	uint32_t get_fattime(void);

#ifdef __cplusplus
}
#endif // __cplusplus
