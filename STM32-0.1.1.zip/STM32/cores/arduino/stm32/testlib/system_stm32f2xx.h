#pragma once

extern void systemInit(void);
