#pragma once

#include "SerialPort.h"

namespace Hardware
{
	extern "C"
	{
		void USART2_IRQHandler();
	}

	class RS232_t : public SerialPort
	{
		friend void USART2_IRQHandler();
	protected:
		RS232_t();
	public:
		static RS232_t & instance();
		virtual uint getBitrate() override final;
		virtual void setBitrate(uint32_t bitrate) override final;
	};
}
