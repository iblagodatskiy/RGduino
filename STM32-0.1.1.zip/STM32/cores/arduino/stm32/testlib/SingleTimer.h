#pragma once

#include "Timer.h"
#include "CoreSettings.h"
#include "InputChannel.h"

class SingleTimer : protected System::Timer
{
	friend class Periphery;

	InputChannel &channel;
	bool modeFreqEn;
	bool sync;
	bool prescalerUpdate;
	byte overflow;
	uint counter;
	bool counterEnable = true;
	byte divider;
	ushort tune;
protected:
	void clearCounter();
	void setCounterState(bool enabled);
	TIM_TypeDef *timer;

	void interrupt();
	void measure();
	void stop();
	bool enable();
	void disable();
	void increaseDivider();
	void decreaseDivider();
	virtual void tick_10Hz();//10Hz
	SingleTimer(TIM_TypeDef *tim, void (*init_clock)(), InputChannel &chan);
};
