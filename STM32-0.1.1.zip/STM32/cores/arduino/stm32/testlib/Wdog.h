#pragma once

#include "Timer.h"

class WDt : System::Timer
{
	WDt();
	virtual void tick_50Hz();
public:
	static WDt & instance();
};
