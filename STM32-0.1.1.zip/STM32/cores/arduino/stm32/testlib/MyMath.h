#pragma once

#include "Types.h"
#include <utility>

template <typename T>
bool inRange(T value, T min, T max)
{
	return value >= min && value <= max;
}

template <typename T>
bool outOfRange(T value, T min, T max)
{
	return value < min || value > max;
}

void zeroMemory(void *ptr, uint cnt);

void memCopy(byte *to, byte *from, uint length);

void modBusCRC(byte value, ushort &next);

byte getFirstActiveBit(uint data);

template <typename T>
void shiftLeft(T * array, ushort cnt)
{
	if(cnt > 1) for(ushort i = 0; i < cnt; i++) array[i] = array[i + 1];
}

template <typename T>
void shiftRight(T * array, ushort cnt)
{
	if(cnt > 1) for(ushort i = cnt - 1; i > 0; i--) array[i] = array[i - 1];
}

template <typename T>
byte bitCount(T val, byte bit)
{
	bit &= 1;
	byte size = sizeof(T) * 8;// size in bits
	byte count = 0;
	for(byte i = 0; i < size; i++) if((((val >> i) & 1) ^ bit) == 0) count++;
	return count;
}

enum class SortOrder : bool
{
	DecreaseOrder,
	IncreaseOrder
};

template <typename T>
void bubbleSort(T *buf, uint len, SortOrder order)
{
	if (len > 1)
	{
		T temp;
		bool find = true;
		while (find)
		{
			find = false;
			for (uint i = 1; i < len; i++)
			{
				if ((order == SortOrder::IncreaseOrder) ? buf[i] < buf[i - 1] : buf[i] > buf[i - 1])
				{
					std::swap(buf[i], buf[i - 1]);
					find = true;
				}
			}
		}
	}	
}

template <typename Condition, typename Buffer>
void associatedSort(Condition *condition, Buffer *buf, ushort len, SortOrder order)
{
	if(len > 1)
	{
		bool find = true;
		while(find)
		{
			find = false;
			for(ushort i = 1; i < len; i++)
			{
				if((order == SortOrder::DecreaseOrder) ? condition[i] < condition[i - 1] : condition[i] > condition[i - 1])
				{
					std::swap(condition[i], condition[i - 1]);
					std::swap(buf[i], buf[i - 1]);
					find = true;
				}
			}
		}
	}
}
template <typename Buffer>
void associatedSortType(Buffer *buf, ushort len, SortOrder order)
{
	if(len > 1)
	{
		bool find = true;
		while(find)
		{
			find = false;
			for(ushort i = 1; i < len; i++)
			{
				if((order == SortOrder::DecreaseOrder) ? buf[i].type < buf[i - 1].type : buf[i].type > buf[i - 1].type)
				{
					std::swap(buf[i], buf[i - 1]);
					find = true;
				}
			}
		}
	}
}

#define FILTER_MAX 20

class SimpleAverage
{
	float buf[FILTER_MAX];
	byte counter;
	byte amount;
	float result;
	float threshold;
	float difference;
	float cSum;
public:
	SimpleAverage();
	float get();
	float add(float val);
};
