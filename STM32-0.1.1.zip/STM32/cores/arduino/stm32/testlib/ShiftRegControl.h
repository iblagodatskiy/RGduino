#pragma once

#include "GPIOLib.h"
#include "Config.h"
#include "OverLoadControl.h"

#if (OVER_LOAD_CONTROL ==1)
extern "C" void TIM8_BRK_TIM12_IRQHandler();
class Periphery;
#endif // OVER_LOAD_CONTROL

namespace Hardware
{
#if (OVER_LOAD_CONTROL ==1)
	extern "C" void SPI2_IRQHandler();
#endif // OVER_LOAD_CONTROL

	class ShiftRegControl
#if (OVER_LOAD_CONTROL ==1)
		: public OverLoadControl
#endif // OVER_LOAD_CONTROL
	{
		static bool initialized;
#if (OVER_LOAD_CONTROL ==1)
		friend void SPI2_IRQHandler();
		friend void ::TIM8_BRK_TIM12_IRQHandler();
		friend class ::Periphery;
		static bool active;
		static byte asyncCounterS;
		static byte asyncCounterR;
		static bool halfReaded;
		static bool asyncWrite;
		static void getOutputStatusAsync();
		static ushort rBuf[3];
		static byte glitchCounter;
#endif // OVER_LOAD_CONTROL
	protected:
		static void writeInputControl(ushort *buf);
		static bool writeDiscretes(ushort data);
		static bool getOutputStatus(ushort *data);
	public:
		ShiftRegControl();
#if (OVER_LOAD_CONTROL ==1)
		static bool getBusy();
#endif // OVER_LOAD_CONTROL
	};
}

#define STATUS_LATCH_PIN				13
#define STATUS_LATCH_ACTIVATE			GPIOresetPin(GPIOE, STATUS_LATCH_PIN)
#define STATUS_LATCH_DEACTIVATE			GPIOsetPin(GPIOE, STATUS_LATCH_PIN)

#define CONTROL_CLOCK_EN_PIN			11 //GPIOB
#define CONTROL_CLOCK_ENABLE			GPIOsetPin(GPIOB, CONTROL_CLOCK_EN_PIN)
#define CONTROL_CLOCK_DISABLE			GPIOresetPin(GPIOB, CONTROL_CLOCK_EN_PIN)

#define CONTROL_CLOCK_SWITCH_PIN		15 //GPIOE
#define CONTROL_CLOCK_SWITCH_DISCRETES	GPIOresetPin(GPIOE, CONTROL_CLOCK_SWITCH_PIN)
#define CONTROL_CLOCK_SWITCH_INPUTS		GPIOsetPin(GPIOE, CONTROL_CLOCK_SWITCH_PIN)

#define DISCRETES_CONTROL_EN_PIN		10 //GPIOE
#define DISCRETES_CONTROL_ENABLE		GPIOresetPin(GPIOE, DISCRETES_CONTROL_EN_PIN)
#define DISCRETES_CONTROL_DISABLE		GPIOsetPin(GPIOE, DISCRETES_CONTROL_EN_PIN)

#define DISCRETES_CONTROL_LATCH_PIN		11 //GPIOE
#define DISCRETES_CONTROL_LATCH_ENABLE	GPIOsetPin(GPIOE, DISCRETES_CONTROL_LATCH_PIN)
#define DISCRETES_CONTROL_LATCH_DISABLE	GPIOresetPin(GPIOE, DISCRETES_CONTROL_LATCH_PIN)

#define DISCRETES_CONTROL_RESET_PIN		12 //GPIOE
#define DISCRETES_CONTROL_RESET_ENABLE	GPIOresetPin(GPIOE, DISCRETES_CONTROL_RESET_PIN)
#define DISCRETES_CONTROL_RESET_DISABLE	GPIOsetPin(GPIOE, DISCRETES_CONTROL_RESET_PIN)

#define INPUTS_CONTROL_LATCH_PIN		2 //GPIOG
#define INPUTS_CONTROL_LATCH_ENABLE		GPIOsetPin(GPIOG, INPUTS_CONTROL_LATCH_PIN)
#define INPUTS_CONTROL_LATCH_DISABLE	GPIOresetPin(GPIOG, INPUTS_CONTROL_LATCH_PIN)

#define INPUTS_CONTROL_RESET_PIN		8 //GPIOG
#define INPUTS_CONTROL_RESET_ACTIVATE	GPIOresetPin(GPIOG, INPUTS_CONTROL_RESET_PIN)
#define INPUTS_CONTROL_RESET_DEACTIVATE	GPIOsetPin(GPIOG, INPUTS_CONTROL_RESET_PIN)
