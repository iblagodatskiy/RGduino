/*
 * Factory.h
 *
 *  Created on: 21 ��� 2020 �.
 *      Author: PShashkov
 */
#ifndef FACTORY_H
#define FACTORY_H
#include "Manager.h"
#include <string>
#include <map>
#include "typeinfo"
#include "CAN.h"
#include "CRC.h"
#include "EEPROM.h"
#include "RS232.h"
#include "RS485.h"
#include "Flash.h"
#include "SDIO.h"

using namespace Hardware;
using namespace System;

class Factory {
private:
	Factory(const Factory&) {
	}
	Factory& operator=(const Factory&) {
		return *this;
	}
	struct arr_link {
		size_t type_obj;
		void *link_obj;
	};
	static arr_link instances[20];
	static uint8_t count_obj;
public:
	static void destroy() {
	}

	template<typename Type>
	static Type & get() {
		Type *  tmp_pointer=NULL;
		for(uint8_t i=0; i<count_obj;i++)
		{
			if(instances[i].type_obj==typeid(Type).hash_code())
			{
				tmp_pointer=static_cast<Type *>(instances[i].link_obj);
				break;
			}
		}
		if(tmp_pointer==NULL)
		{
			tmp_pointer=static_cast<Type *>(&Type::instance());
			instances[count_obj].type_obj = typeid(Type).hash_code();
			instances[count_obj].link_obj =tmp_pointer ;
			count_obj++;
		}
		return static_cast<Type &>(*tmp_pointer);
	}
	template<typename Type>
	static void include() {
		instances[count_obj].type_obj = typeid(Type).hash_code();
		instances[count_obj++].link_obj = &Type::instance();
	}
	Factory() {
	}
	virtual ~Factory() {
	}
};

#endif
