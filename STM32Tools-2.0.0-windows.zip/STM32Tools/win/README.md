## Binaries for Windows tools

* busybox.exe : Tool for running `run_arduino_gen.sh`.
Currently FRP-3244-g48128b9aa release, downloaded from [busybox-w32].

[busybox-w32]: https://frippery.org/busybox/
